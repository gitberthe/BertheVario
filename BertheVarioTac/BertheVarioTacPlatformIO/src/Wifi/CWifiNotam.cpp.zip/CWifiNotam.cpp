

#include "../BertheVarioTac.h"

//#include <WifiClientSecure.h>

bool CWifiNotam::InitClient()
{
String SSID = g_GlobalVar.m_Config.m_Ssid.c_str() ;
String PASSWD = g_GlobalVar.m_Config.m_Passwd.c_str() ;
WiFi.begin( SSID , PASSWD );
while(WiFi.status() != WL_CONNECTED)
    delay(500);
g_tft.setCursor( 0 , 0 ) ;
g_tft.print( WiFi.localIP() ) ;

WiFiClient client;
HTTPClient http;
//String serverPath = "https://pdd.dprslt.fr/spaces/notams" ;
//String serverPath = "http://httpforever.com/" ;
String serverPath = "https://www.google.fr" ;

//client.setInsecure();

http.begin(serverPath);

int httpResponseCode = http.GET();

if (httpResponseCode>0)
    {
    http.end() ;
    return true ;
    }

http.end() ;
return false ;
}
