
#pragma once

class CWifiNotam
{
public :
    bool InitClient() ;
    void GetDprslt() ;
} ;

