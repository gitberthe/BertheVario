//////////////////////////////////////////////////////////////////////////////
/// \file CLGList_inl.cpp
/// \date 18/01/2001 : Creation du fichier.
///
/// \brief Implementation de CLGPtrList
///
/// \date 05/09/2023 : Derniere modification.
///

/////////////////////////////////////////////////////////////////////////////
/// \brief
template < class T >
CLGPtrList< T >::CLGPtrList()
{
}

/////////////////////////////////////////////////////////////////////////////
/// \brief
template < class T >
CLGPtrList< T >::CLGPtrList( const CLGPtrList & ListToCopy )
{
*this = ListToCopy ;
}

/////////////////////////////////////////////////////////////////////////////
/// \brief Detruit toute la liste chaiée et ses donnees.
template < class T >
void CLGPtrList< T >::DeleteAll()
{
while ( !CLGLObjets<T*>::IsEmpty() )
    {
    delete CLGLObjets<T*>::GetHead() ;
    CLGLObjets<T*>::RemoveHead() ;
    }
}

/////////////////////////////////////////////////////////////////////////////
/// \brief recopie une liste chainee en duplicant les pointeurs.
template < class T >
CLGPtrList< T > & CLGPtrList< T >::operator = ( const CLGPtrList & ListToCopy )
{
if ( this == & ListToCopy )
    return *this ;

DeleteAll() ;

const T * pClasstoCopy ;
T * pClassCopied ;
const CLGNode< T * > * pos = ListToCopy.GetHeadPosition() ;
while( pos != NULL )
    {
    pClasstoCopy = pos->data ;
    ASSERT( pClasstoCopy != NULL ) ;
    pClassCopied = new T( *pClasstoCopy ) ;
    CLGPtrList< T >::AddTail( pClassCopied ) ;
    pos = pos->pNext ;
    }

return *this ;
}

