//////////////////////////////////////////////////////////////////////////////
/// \file CLGList.h
/// \date 23/03/2002 : date de creation
/// \addtogroup LibGeneral
/// \brief CLGList.
///
/// \date 04/12/2010 : Passage des classes avec le prefixe CLG (librairie Generale)
/// \date 04/01/2017 : Derniere modification.
///

#ifndef __CMYLIST_H__
#define __CMYLIST_H__

/////////////////////////////////////////////////////////////////////////////
/// \brief Liste chainée d'objets, classe presque vide (utilise CLGLObjets).
template < class T >
class CLGList : public CLGLObjets< T >
{
public :
    // CLGList() ;
    // CLGList( CLGList & ) ;
    // CLGList & operator = ( CLGList & ) ;
} ;

/****************************************************************************/

/////////////////////////////////////////////////////////////////////////////
/// \brief Liste chainée de pointeurs d'objets, classe presque vide (utilise CLGLObjets).
template < class T >
class CLGPtrList : public CLGLObjets< T * >
{
public :
    CLGPtrList() ;
    CLGPtrList( const CLGPtrList & ) ;
    ~CLGPtrList()
        {DeleteAll();} ;

    /*// fonctions virtuelles
    virtual CLGNode<T>* GetHeadPosition() const = 0 ;
    virtual int      IsEmpty() const = 0 ;
    virtual T&       GetHead() = 0 ;
    virtual T        RemoveHead() = 0 ;
    virtual T        RemoveTail() = 0 ;*/

    CLGPtrList & operator = ( const CLGPtrList & ) ;
    void DeleteAll() ;
} ;

#include "CLGList_inl.h"

#endif // __CMYLIST_H__

