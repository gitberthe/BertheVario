//////////////////////////////////////////////////////////////////////////////
/// \file CLGMap.h
/// \date 07/06/2020 : Date de creation
///
/// \brief Fichier de definition de CLGMap .
///
/// \date 21/04/2024 : derniere modification.
///

#ifndef CMAPMFCTOLG
#define CMAPMFCTOLG

struct __POSITION {};
typedef __POSITION* POSITION;

#define COEF_HASH_TABLE ((float)1.15)
#define BEFORE_START_POSITION ((POSITION)-1L)
void TestMap() ;

//////////////////////////////////////////////////////////////////////////////
/// \brief Compare 2 elements passe par pointeur.
template<class TYPE, class ARG_TYPE>
inline bool CompareElements(const TYPE* pElement1, const ARG_TYPE* pElement2)
{
ASSERT(pElement1 != NULL && pElement2 != NULL);
return *pElement1 == *pElement2;
}

//////////////////////////////////////////////////////////////////////////////
/// \brief Pour une fonction de hachage plus rapide
inline ldiv_t MyLdiv( int num , int den  )
{
ldiv_t ret ;
ret.quot = num/den ;
ret.rem = num - ret.quot ;
return ret ;
}

//////////////////////////////////////////////////////////////////////////////
/// \brief Fonction de hachage.
template<class ARG_KEY>
inline unsigned int HashKeyMod(ARG_KEY key)
{
//ldiv_t HashVal = MyLdiv((int)(ARG_KEY)key, 127773);
//HashVal.rem =  HashVal.rem - 2836 * HashVal.quot; // berthe modif
return ((unsigned int)key);
}

template<class ARG_KEY>
unsigned int HashKeyOri(ARG_KEY key)
{
// (algorithm copied from STL hash in xfunctional)
/*ldiv_t HashVal = ldiv((int)(ARG_KEY)key, 127773);
HashVal.rem = 16807 * HashVal.rem - 2836 * HashVal.quot;
if (HashVal.rem < 0)
	HashVal.rem += 2147483647;
return ((unsigned int)HashVal.rem);
*/
ldiv_t HashVal = MyLdiv((int)(ARG_KEY)key, 127773);
HashVal.rem =  16807 * HashVal.rem - 2836 * HashVal.quot;
if (HashVal.rem < 0)
	HashVal.rem += 2147483647;
return ((unsigned int)HashVal.rem);
}

/*****************************************************************************/

#define NB_ASSOC_IN_BLOCK_MAP  50

class CLGAssocAssocBlock ;

//////////////////////////////////////////////////////////////////////////////
/// \brief Classe qui associe une classe clee a une classe valeur (ne fonction
/// pas a RemoveKey() si la clee est une CLGString. Utiliser CLGMapStringTo).
/// exemple : CLGMap<int,int,CLGString,CLGString&> Map ;
template<class KEY,class VALUE>
class CLGMap
{
public:
	/// \brief CLGPair paire cle/valeur
	class CLGPair
        {
        public :
            KEY     m_key;  ///< clee
            VALUE   m_value;///< valeur
        protected:
            CLGPair() {} ;
            CLGPair( KEY keyval ) : m_key( keyval )	{}
        };

protected:
	/// \brief Association valeur de hachage/CLGPair/pointeur de liste chainee
	class CLGAssoc : public CLGPair
        {
            friend class CLGMap<KEY,VALUE>;
            friend class CLGAssocAssocBlock ;
            CLGAssoc*       m_pNext ;         ///< pointeur sur la prochaine CLGAssoc
            unsigned int   m_nHashValue;     ///< valeur de hachage needed for efficient iteration
            bool            m_NonValidFree ;  ///< indique si la table est toujours valide dans la map ou si elle doit etre liberee
        public:
            CLGAssoc() {m_pNext=NULL;} ;
            CLGAssoc( KEY key ) : CLGPair( key ) {m_pNext=NULL;}

           	bool IsValid() const
                { return !m_NonValidFree ; } ;

            bool operator > ( const CLGAssoc & OtherClass ) const ;
            bool operator < ( const CLGAssoc & OtherClass ) const ;
        };

    /// \brief classe pour une allocation de CLGAssoc par packets (plus rapide)
    class CLGAssocAssocBlock
        {
        public :
            CLGAssocAssocBlock() { m_AssocArr = new CLGAssoc [NB_ASSOC_IN_BLOCK_MAP] ; } ;
            ~CLGAssocAssocBlock() { delete [] m_AssocArr ; }

            int        m_NbUsed = 0 ;  ///< nombre d'utilisé dans le packet
            CLGAssoc *  m_AssocArr ;    ///< tableau des packets

            /// \brief pour liberation du packet
            bool IsAllFree() const
                {
                int AllFree = true ;
                for ( int ia = 0 ; ia < m_NbUsed ; ia++ )
                    if ( ! m_AssocArr[ia].m_NonValidFree )
                        {
                        AllFree = false ;
                        break ;
                        }
                return AllFree ;
                }
        } ;

public:
// Construction
    explicit CLGMap( const CLGMap & Map ) ;
    explicit CLGMap();

// Attributes
	// number of elements
	int GetCount() const;
	bool IsEmpty() const;

	// Lookup
	bool            Lookup(KEY key, VALUE& rValue) const;
	const CLGPair * PLookup(KEY key) const;
	CLGPair *       PLookup(KEY key);

	void GetMinMaxMoyListe( int & Min , int & Max , float & Moy ) ;

// Operations
	// Lookup and add if not there
	VALUE& operator[](KEY key);
	const VALUE* GetAtValue(KEY key) const ;

	// add a new (key, value) pair
	void SetAt(KEY key,VALUE &newValue);

	// removing existing (key, ?) pair
	bool RemoveKey(KEY key);
	void RemoveAll();

	// iterating all (key, value) pairs
	POSITION GetStartPosition() const;

	const CLGPair *PGetFirstAssoc() const;
	CLGPair *PGetFirstAssoc();

	void GetNextAssoc(POSITION& rNextPosition, KEY& rKey, VALUE& rValue) const;

	const CLGPair *PGetNextAssoc(const CLGPair *pAssocRet) const;
	CLGPair *PGetNextAssoc(const CLGPair *pAssocRet);

	// advanced features for derived classes
	unsigned int GetHashTableSize() const;
	bool          GetOriginalHash() const
                    { return m_OriginalHash;} ;
	void InitHashTable(unsigned int hashSize, bool bAllocNow = true , bool OriginalHash = false );
	void MultHashTable( float Coef ) ;

	const CLGMap & operator = ( const CLGMap & Map ) ;

    void CompressMap() ;
	void TriAdapte( bool Tri = TRI_CROISSANT ) ;
	void Shuffle() ;
    CLGAssoc * GetAt( int i )
        { return m_FreeAssocArrp[i] ; } ;
    const CLGAssoc * GetAt( int i ) const
        { return m_FreeAssocArrp[i] ; } ;
    int GetSizeFree() const
        { return m_FreeAssocArrp.GetSize() ; } ;

// Implementation
protected:
	CLGAssoc**      m_pHashTable;       ///< table de hachage
	unsigned int   m_nHashTableSize;   ///< inteur de la table de hachage
	int            m_nCount;           ///< nombre d'element dans la table

	CLGAssoc*   NewAssoc(KEY key);
	void        FreeAssoc(CLGAssoc*);
	CLGAssoc*   GetAssocAt(KEY, unsigned int&, unsigned int&) const;

public:
	~CLGMap();

private :
    bool                  m_OriginalHash = false ;  ///< si table de hashage otiginale
    CLGArrayPtr<CLGAssoc> m_FreeAssocArrp ;         ///< tableau des poiunteur tous les CLGAssoc de la vie de la map
    CLGPtrList<CLGAssocAssocBlock> m_AllocatedAssocBlockListp ;///< Liste chainee tableau des block de CLGAssoc alloue pour optimization malloc

};

/*============================================================================*/
// CLGMap<KEY, VALUE> inline functions

//////////////////////////////////////////////////////////////////////////////
/// \brief
template<class KEY, class VALUE>
bool CLGMap<KEY, VALUE>::CLGAssoc::operator > ( const CLGMap<KEY, VALUE>::CLGAssoc & OtherClass ) const
{
return CLGMap<KEY, VALUE>::CLGAssoc::m_value > OtherClass.m_value ;
}

//////////////////////////////////////////////////////////////////////////////
/// \brief
template<class KEY, class VALUE>
bool CLGMap<KEY, VALUE>::CLGAssoc::operator < ( const CLGMap<KEY, VALUE>::CLGAssoc & OtherClass ) const
{
return CLGMap<KEY, VALUE>::CLGAssoc::m_value < OtherClass.m_value ;
}

//////////////////////////////////////////////////////////////////////////////
/// \brief Compresse les clees detruites dans m_FreeAssocArrp puis fait un
/// FreeExtra.
template<class KEY, class VALUE>
void CLGMap<KEY, VALUE>::CompressMap()
{
for ( int it = 0 ; it < m_FreeAssocArrp.GetSize() ; it ++ )
    if ( m_FreeAssocArrp[it]->m_NonValidFree )
        {
        //delete m_FreeAssocArrp[it] ;
        m_FreeAssocArrp[it] = NULL ;
        }

// compress null
m_FreeAssocArrp.CompressNull() ;
m_FreeAssocArrp.FreeExtra() ;

// compression de la liste de block alloués
CLGNode<CLGAssocAssocBlock*> * pList = m_AllocatedAssocBlockListp.GetHeadPosition() ;
while( pList != NULL )
    {
    ASSERT( pList != NULL ) ;
    ASSERT( pList->m_data != NULL ) ;
    CLGNode<CLGAssocAssocBlock*> * SavpList = pList ;
    pList = pList->m_pNext ;
    if ( SavpList->m_data->IsAllFree() )
        {
        delete SavpList->m_data ;
        m_AllocatedAssocBlockListp.RemoveAt( SavpList ) ;
        }
    }
}

//////////////////////////////////////////////////////////////////////////////
/// \brief Tri le m_FreeAssocArrp pour un parcour croissant/decroissant
template<class KEY, class VALUE>
void CLGMap<KEY, VALUE>::TriAdapte( bool Tri )
{
CompressMap() ;
m_FreeAssocArrp.TriAdapte( Tri ) ;
}

//////////////////////////////////////////////////////////////////////////////
/// \brief
template<class KEY, class VALUE>
void CLGMap<KEY, VALUE>::Shuffle()
{
CompressMap() ;
m_FreeAssocArrp.Shuffle() ;
}

//////////////////////////////////////////////////////////////////////////////
/// \brief Renoie le mininmum/maximum/moyenne de profondeur de liste chainee
template<class KEY, class VALUE>
void CLGMap<KEY, VALUE>::GetMinMaxMoyListe( int & Min , int & Max , float & Moy )
{
if ( GetCount() == 0 || m_pHashTable == NULL )
    {
    Min = Max = Moy = 0 ;
    return ;
    }

int NbListe = 0 ;
Moy = 0 ;
Min = LONG_MAX ;
Max = -LONG_MAX ;

CLGAssoc * pAssoc ;
for (unsigned int nBucket = 0; nBucket < m_nHashTableSize; nBucket++)
    {
	if ((pAssoc = m_pHashTable[nBucket]) != NULL)
        {
        NbListe++ ;
        int Count = 0 ;
        while( pAssoc != NULL )
            {
            Count++ ;
            pAssoc = pAssoc->m_pNext ;
            }
        Min = MIN( Min , Count ) ;
        Max = MAX( Max , Count ) ;
        Moy += Count ;
        }
	}
if ( NbListe > 0 )
    Moy /= NbListe ;
}

//////////////////////////////////////////////////////////////////////////////
/// \brief operateur de recopie.
template<class KEY, class VALUE>
const  CLGMap<KEY, VALUE> & CLGMap<KEY, VALUE>::operator = ( const CLGMap<KEY, VALUE> & Map )
{
// si meme instance
if ( this == &Map )
    return *this ;

// destruction de tous
RemoveAll() ;

m_OriginalHash = Map.m_OriginalHash ;

// init table de hashage
InitHashTable( Map.GetHashTableSize() , true , m_OriginalHash ) ;

// recopie des donnees
const CLGPair * pPair = Map.PGetFirstAssoc() ;
while( pPair != NULL )
    {
    (*this)[pPair->m_key] = pPair->m_value ;
    pPair = Map.PGetNextAssoc( pPair ) ;
    }

// retour
return *this ;
}

//////////////////////////////////////////////////////////////////////////////
/// \brief Renseigne si la table est vide.
template<class KEY, class VALUE>
bool CLGMap<KEY, VALUE>::IsEmpty() const
	{ return m_nCount == 0; }

//////////////////////////////////////////////////////////////////////////////
/// \brief Insere une nouvelle clee/valeur. Si la clee est deja presente, la
/// valeur est modifier.
template<class KEY, class VALUE>
inline void CLGMap<KEY, VALUE>::SetAt(KEY key, VALUE & newValue)
	{ (*this)[key] = newValue; }

//////////////////////////////////////////////////////////////////////////////
/// \brief Renvoi la debut de la CLGMap.
template<class KEY, class VALUE>
POSITION CLGMap<KEY, VALUE>::GetStartPosition() const
	{ return (m_nCount == 0) ? NULL : BEFORE_START_POSITION; }

//////////////////////////////////////////////////////////////////////////////
/// \brief Renvoie un CLGPair * de la premierre association.
template<class KEY, class VALUE>
const typename CLGMap<KEY, VALUE>::CLGPair* CLGMap<KEY, VALUE>::PGetFirstAssoc() const
{
if(m_nCount == 0) return NULL;

ASSERT(m_pHashTable != NULL);  // never call on empty map

CLGAssoc* pAssocRet = (CLGAssoc*)BEFORE_START_POSITION;

// find the first association
for (unsigned int nBucket = 0; nBucket < m_nHashTableSize; nBucket++)
	if ((pAssocRet = m_pHashTable[nBucket]) != NULL)
		break;
ASSERT(pAssocRet != NULL);  // must find something

return pAssocRet;
}

//////////////////////////////////////////////////////////////////////////////
/// \brief Renvoie un CLGPair * de la premiere association.
template<class KEY, class VALUE>
inline typename CLGMap<KEY, VALUE>::CLGPair* CLGMap<KEY, VALUE>::PGetFirstAssoc()
{
if(m_nCount == 0) return NULL;

ASSERT(m_pHashTable != NULL);  // never call on empty map

CLGAssoc* pAssocRet = (CLGAssoc*)BEFORE_START_POSITION;

// find the first association
for (unsigned int nBucket = 0; nBucket < m_nHashTableSize; nBucket++)
	if ((pAssocRet = m_pHashTable[nBucket]) != NULL)
		break;
ASSERT(pAssocRet != NULL);  // must find something

return pAssocRet;
}

//////////////////////////////////////////////////////////////////////////////
/// \brief Renvoie la taille de la table de hachage.
template<class KEY, class VALUE>
inline unsigned int CLGMap<KEY, VALUE>::GetHashTableSize() const
	{ return m_nHashTableSize; }

/*============================================================================*/
// CLGMap<KEY, VALUE> out-of-line functions

//////////////////////////////////////////////////////////////////////////////
/// \brief Constructeur.
template<class KEY, class VALUE>
CLGMap<KEY, VALUE>::CLGMap()
{
m_pHashTable = NULL;
m_nHashTableSize = 17;  // default size
m_FreeAssocArrp.SetDeleteObjet(false) ;
m_nCount = 0;
}

//////////////////////////////////////////////////////////////////////////////
/// \brief operateur de recopie.
template<class KEY, class VALUE>
CLGMap<KEY, VALUE>::CLGMap( const CLGMap<KEY, VALUE> & Map )
{
m_pHashTable = NULL ;
m_nHashTableSize = 17;  // default size
m_FreeAssocArrp.SetDeleteObjet(false) ;
m_nCount = 0;
*this = Map ;
}

//////////////////////////////////////////////////////////////////////////////
/// \brief Initialise la table de hachage (pour bien faire initialiser a taille
/// maximum + 20%). Et initialise la taille des blocks.
template<class KEY, class VALUE>
void CLGMap<KEY, VALUE>::InitHashTable(
	unsigned int nHashSize, bool bAllocNow, bool OriginalHash )
//
// Used to force allocation of a hash table or to override the default
//   hash table size of (which is fairly small)
{
ASSERT(m_nCount == 0);
//ASSERT(nHashSize > 0);

// taille de haschage minimun
if ( nHashSize < m_nHashTableSize )
    nHashSize = m_nHashTableSize ;

// positionne la croissance et force l'allocation immediate
ASSERT( m_FreeAssocArrp.GetSize() == 0 ) ;
//m_FreeAssocArrp.SetGrow(nHashSize/10) ;
//m_AllocatedAssocBlockArrp.SetDeleteObjet(true) ;
//m_AllocatedAssocBlockArrp.SetGrow(nHashSize/(10*NB_ASSOC_IN_BLOCK));

m_OriginalHash = OriginalHash ;

if ( m_nCount > 0 )
    {
    cout << "InitHashTable() avec des donnees dedans !!!!" << endl ;
    RemoveAll() ;
    }

if (m_pHashTable != NULL)
    {
	// free hash table
	delete[] m_pHashTable;
	m_pHashTable = NULL;
    }

if (bAllocNow)
    {
	m_pHashTable = new CLGAssoc* [nHashSize];
	ASSERT(m_pHashTable != NULL);
	memset(m_pHashTable, 0, sizeof(CLGAssoc*) * nHashSize);
    }
m_nHashTableSize = nHashSize;
}

//////////////////////////////////////////////////////////////////////////////
/// \brief Initialise la table de hachage avec le coefficient multiplicateur
/// et recopie les donnees.
/// \param Coef [in] : coef de multiplication de la table de hachage precendente
template<class KEY, class VALUE>
void CLGMap<KEY, VALUE>::MultHashTable( float Coef )
{
CLGMap<KEY, VALUE> TmpMap ;
TmpMap = *this ;

ASSERT( Coef > 0. ) ;
ASSERT( Coef > 1. ) ;

// nouvelle table de hachage
RemoveAll() ;
InitHashTable( TmpMap.GetHashTableSize() * Coef , true , m_OriginalHash ) ;

// recopie des donnees
auto pPair = TmpMap.PGetFirstAssoc() ;
while( pPair != NULL )
    {
    // recopie des donnees
    (*this)[pPair->m_key] = pPair->m_value ;

    pPair = TmpMap.PGetNextAssoc( pPair ) ;
    }
}

//////////////////////////////////////////////////////////////////////////////
/// \brief Vide la map.
template<class KEY, class VALUE>
inline int CLGMap<KEY, VALUE>::GetCount() const
{
return m_nCount ;
}

//////////////////////////////////////////////////////////////////////////////
/// \brief Vide la map.
template<class KEY, class VALUE>
void CLGMap<KEY, VALUE>::RemoveAll()
{
#ifdef _LG_PROFIL_
int Min ;
int Max ;
float Moy ;
GetMinMaxMoyListe( Min , Max , Moy ) ;
if ( Moy > 1.9 )
    cout << "**** CLGMap<KEY, VALUE>:::RemoveAll() min:" << Min << ", max:" << Max << ", Moy:" << Moy << ", count:" << GetCount() << ", hash:" << GetHashTableSize() << endl ;
#endif

if (m_pHashTable != NULL)
    {
    // free hash table
	delete[] m_pHashTable;
	m_pHashTable = NULL;
	}

m_FreeAssocArrp.DeleteAll() ;
m_AllocatedAssocBlockListp.DeleteAll() ;
m_nCount = 0 ;
}

//////////////////////////////////////////////////////////////////////////////
/// \brief Destructeur.
template<class KEY, class VALUE>
CLGMap<KEY, VALUE>::~CLGMap()
{
RemoveAll();
ASSERT(m_nCount == 0);
}

//////////////////////////////////////////////////////////////////////////////
/// \brief Fonction qui alloue une nouvelle classe.
template<class KEY, class VALUE>
inline typename CLGMap<KEY, VALUE>::CLGAssoc*
CLGMap<KEY, VALUE>::NewAssoc(KEY key)
{
CLGAssocAssocBlock *pAssocBloc ;

// definition du block de CLGAssoc alloue
if ( m_AllocatedAssocBlockListp.GetCount() == 0 )
    {
    pAssocBloc = new CLGAssocAssocBlock ;
    m_AllocatedAssocBlockListp.AddTail( pAssocBloc ) ;
    }
else
    {
    pAssocBloc = m_AllocatedAssocBlockListp.GetTail() ;
    ASSERT( pAssocBloc != NULL ) ;
    }

// si block plein
if ( pAssocBloc->m_NbUsed >= NB_ASSOC_IN_BLOCK_MAP )
    {
    pAssocBloc = new CLGAssocAssocBlock ;
    m_AllocatedAssocBlockListp.AddTail( pAssocBloc ) ;
    }

// utilisation de la CLGAssoc du block
//CLGMap::CLGAssoc* pAssoc = new CLGAssoc(key) ;
CLGMap::CLGAssoc* pAssoc = & pAssocBloc->m_AssocArr[ pAssocBloc->m_NbUsed++ ] ;
ASSERT( pAssocBloc->m_NbUsed <= NB_ASSOC_IN_BLOCK_MAP ) ;

// initialisation de la clee
pAssoc->m_key = key ;

// ajout au tableau des CLGAssoc a liberer
m_FreeAssocArrp.Add( pAssoc ) ;
//pAssoc->m_PosInFreeArrp = m_FreeAssocArrp.GetUpperBound() ;

// indication que pas liberée
pAssoc->m_NonValidFree = false ;

// augmentation du nombre d'element de la map
m_nCount++;

// grow des tableau de pointeur vers les CLGAssoc et block de CLGAssoc
m_FreeAssocArrp.SetGrow( (m_nCount + m_nHashTableSize/4) / 2 ) ;

ASSERT(m_nCount > 0);  // make sure we don't overflow

return pAssoc;
}

//////////////////////////////////////////////////////////////////////////////
/// \brief Fonction qui ne desalloue pas. Met juste la taille a jour
template<class KEY, class VALUE>
inline void CLGMap<KEY, VALUE>::FreeAssoc(CLGAssoc* pAssoc)
{
pAssoc->m_NonValidFree = true ;
m_nCount--;
ASSERT(m_nCount >= 0);  // make sure we don't underflow

// if no more elements, cleanup completely
if (m_nCount == 0)
    RemoveAll();
}

//////////////////////////////////////////////////////////////////////////////
/// \brief Cherche la CLGAssoc correspondant a la clee. Postion dans la table
/// de hachage puis parcour de liste chainee.
/// \param nHashValue[out] : valeur de la clee de hachage
/// \param nHashBucket[out] : position dans de la table de hachage
/// \return reourne NULL si l'association n'existe pas.
template<class KEY, class VALUE>
inline typename CLGMap<KEY, VALUE>::CLGAssoc*
CLGMap<KEY, VALUE>::GetAssocAt(KEY key, unsigned int& nHashBucket, unsigned int& nHashValue) const
// find association (or return NULL)
{
if ( m_OriginalHash )
	nHashValue  = HashKeyOri<KEY>(key);
else
    nHashValue  = HashKeyMod<KEY>(key);
nHashBucket = nHashValue % m_nHashTableSize;

if (m_pHashTable == NULL)
	return NULL;

// see if it exists
for ( CLGAssoc* pAssoc = m_pHashTable[nHashBucket]; pAssoc != NULL; pAssoc = pAssoc->m_pNext)
    {
	if (pAssoc->m_nHashValue == nHashValue && CompareElements(&pAssoc->m_key, &key))
		return pAssoc;
    }
return NULL;
}

//////////////////////////////////////////////////////////////////////////////
/// \brief Renvoie la valeur à la position key.
/// \return true si la clee a ete trouvee.
template<class KEY, class VALUE>
inline bool CLGMap<KEY, VALUE>::Lookup(KEY key, VALUE& rValue) const
{
	unsigned int nHashBucket, nHashValue;
	CLGAssoc* pAssoc = GetAssocAt(key, nHashBucket, nHashValue);
	if (pAssoc == NULL)
		return false;  // not in map

	rValue = pAssoc->m_value;
	return true;
}

//////////////////////////////////////////////////////////////////////////////
/// \brief Renvoie un CLGPair * a la clee key.
template<class KEY, class VALUE>
inline const typename CLGMap<KEY, VALUE>::CLGPair* CLGMap<KEY, VALUE>::PLookup(KEY key) const
{
	unsigned int nHashBucket, nHashValue;
	CLGAssoc* pAssoc = GetAssocAt(key, nHashBucket, nHashValue);
	return pAssoc;
}

//////////////////////////////////////////////////////////////////////////////
/// \brief Renvoie un CLGPair * a la clee key.
template<class KEY, class VALUE>
inline typename CLGMap<KEY, VALUE>::CLGPair* CLGMap<KEY, VALUE>::PLookup(KEY key)
{
	unsigned int nHashBucket, nHashValue;
	CLGAssoc* pAssoc = GetAssocAt(key, nHashBucket, nHashValue);
	return pAssoc;
}

//////////////////////////////////////////////////////////////////////////////
/// \brief Postisionne la valeur à la position key.
template<class KEY, class VALUE>
inline VALUE& CLGMap<KEY, VALUE>::operator[](KEY key)
{
#ifdef _LG_PROFIL_
if ( (int)GetCount() > (int)GetHashTableSize() )
    cout << "********** count : " << GetCount() << ", hashsize : " << GetHashTableSize() << " " << __FILE__ << " " << __LINE__ << endl ;
#endif

unsigned int nHashBucket ; // position dans la table
unsigned int  nHashValue ; // valeur de la cle de hachage
CLGAssoc* pAssoc;
// si la cle est nouvelle
if ((pAssoc = GetAssocAt(key, nHashBucket, nHashValue)) == NULL)
    {
    // creation de la table de hachage
	if (m_pHashTable == NULL)
		InitHashTable(m_nHashTableSize , true , m_OriginalHash );

	ASSERT(m_pHashTable);
	// it doesn't exist, add a new Association
	pAssoc = NewAssoc(key);
	pAssoc->m_nHashValue = nHashValue;

	// insertion en tete de la liste dans la table de hash
	pAssoc->m_pNext = m_pHashTable[nHashBucket];
	m_pHashTable[nHashBucket] = pAssoc;
    }
return pAssoc->m_value;  // return new reference
}

//////////////////////////////////////////////////////////////////////////////
/// \brief Postisionne un pointeur sur la valeur à la position key.
/// \return NULL si la clee n'est pas trouvée
template<class KEY, class VALUE>
inline const VALUE * CLGMap<KEY, VALUE>::GetAtValue(KEY key) const
{
#ifdef _LG_PROFIL_
if ( (int)GetCount() > (int)GetHashTableSize() )
    cout << "********** count : " << GetCount() << ", hashsize : " << GetHashTableSize() << " " << __FILE__ << " " << __LINE__ << endl ;
#endif

unsigned int nHashBucket ; // position dans la table
unsigned int  nHashValue ; // valeur de la cle de hachage
CLGAssoc* pAssoc;

// si la cle est nouvelle
if ((pAssoc = GetAssocAt(key, nHashBucket, nHashValue)) == NULL)
    return NULL ;

return & pAssoc->m_value;  // return reference
}

//////////////////////////////////////////////////////////////////////////////
/// \brief Enleve l'element a la position clee. Eneleve de la liste chainee
template<class KEY, class VALUE>
inline bool CLGMap<KEY, VALUE>::RemoveKey(KEY key)
// remove key - return TRUE if removed
{
if (m_pHashTable == NULL)
	return false;  // nothing in the table

unsigned int nHashValue;
CLGAssoc** ppAssocPrev;
if ( m_OriginalHash )
    nHashValue = HashKeyOri<KEY>(key);
else
    nHashValue = HashKeyMod<KEY>(key);

// tete de la liste chaine
ppAssocPrev = &m_pHashTable[nHashValue%m_nHashTableSize];

// parcour de la liste chainee
for ( CLGAssoc* pAssoc = *ppAssocPrev; pAssoc != NULL; pAssoc = pAssoc->m_pNext)
    {
    // si clee trouvee
	if ((pAssoc->m_nHashValue == nHashValue) && CompareElements(&pAssoc->m_key, &key))
        {
		// pointeur noeud suivant du dessus (ou table de hachage)
		// remplacer par noued suivant
		*ppAssocPrev = pAssoc->m_pNext; // on eneleve de la liste
		FreeAssoc(pAssoc);
		return true;
        }
    // pointeur noeud suivant du dessus
	ppAssocPrev = &pAssoc->m_pNext;
    }
return false;  // not found
}

//////////////////////////////////////////////////////////////////////////////
/// \brief Renvoi la prochaine position dans la map ainsi que la clee et valeur
/// courante.
template<class KEY, class VALUE>
inline void CLGMap<KEY, VALUE>::GetNextAssoc(POSITION& rNextPosition,
	KEY& rKey, VALUE& rValue) const
{
ASSERT(m_pHashTable != NULL);  // never call on empty map

CLGAssoc* pAssocRet = (CLGAssoc*)rNextPosition;
ASSERT(pAssocRet != NULL);

if (pAssocRet == (CLGAssoc*) BEFORE_START_POSITION)
    {
	// find the first association
	for (unsigned int nBucket = 0; nBucket < m_nHashTableSize; nBucket++)
        {
		if ((pAssocRet = m_pHashTable[nBucket]) != NULL)
            {
			break;
            }
        }
	ASSERT(pAssocRet != NULL);  // must find something
    }

// find next association
CLGAssoc* pAssocNext;
if ((pAssocNext = pAssocRet->m_pNext) == NULL)
    {
	// go to next bucket
	for (unsigned int nBucket = (pAssocRet->m_nHashValue % m_nHashTableSize) + 1;
            nBucket < m_nHashTableSize; nBucket++)
		if ((pAssocNext = m_pHashTable[nBucket]) != NULL)
			break;
    }

rNextPosition = (POSITION) pAssocNext;

// fill in return data
rKey   = pAssocRet->m_key;
rValue = pAssocRet->m_value; // */

/* CLGAssoc* pAssocRet = (CLGAssoc*)rNextPosition;
ASSERT(pAssocRet != NULL);
ASSERT( GetCount() > 0 ) ;

int ipos ;
// si debut de la boucle
if (pAssocRet == (CLGAssoc*) BEFORE_START_POSITION)
    {
    ipos = 0 ;
    // recherche du premier valide
    while( ipos < m_FreeAssocArrp.GetSize() && m_FreeAssocArrp[ipos]->m_NonValidFree )
        ipos ++ ;
    pAssocRet = (CLGAssoc*) m_FreeAssocArrp[ipos] ;
    }
else
    ipos = pAssocRet->m_PosInFreeArrp ;

ASSERT( ipos >= 0 ) ;
ASSERT( ipos < m_FreeAssocArrp.GetSize() ) ;

// on avance tant que pas valide
do  {
    ipos++ ;
    }
while( ipos < m_FreeAssocArrp.GetSize() && m_FreeAssocArrp[ipos]->m_NonValidFree ) ;

// prochaine position
if ( ipos < m_FreeAssocArrp.GetSize() )
    rNextPosition = (POSITION) m_FreeAssocArrp[ipos] ;
else
    rNextPosition = NULL ;

// fill in return data
rKey   = pAssocRet->m_key;
rValue = pAssocRet->m_value; */
}

//////////////////////////////////////////////////////////////////////////////
/// \brief
template<class KEY, class VALUE>
inline const typename CLGMap<KEY, VALUE>::CLGPair*
CLGMap<KEY, VALUE>::PGetNextAssoc(const typename CLGMap<KEY, VALUE>::CLGPair* pPairRet) const
{
CLGAssoc* pAssocRet = (CLGAssoc*)pPairRet;

ASSERT(m_pHashTable != NULL);  // never call on empty map
ASSERT(pAssocRet != NULL);

if(m_pHashTable == NULL || pAssocRet == NULL)
	return NULL;

ASSERT(pAssocRet != (CLGAssoc*)BEFORE_START_POSITION);

// find next association
CLGAssoc* pAssocNext;
if ((pAssocNext = pAssocRet->m_pNext) == NULL)
    {
	// go to next bucket
	for (unsigned int nBucket = (pAssocRet->m_nHashValue % m_nHashTableSize) + 1;
	  nBucket < m_nHashTableSize; nBucket++)
		if ((pAssocNext = m_pHashTable[nBucket]) != NULL)
			break;
    } // */

/* int ipos = pAssocRet->m_PosInFreeArrp ;

// on avance tant que pas valide
do  {
    ipos++ ;
    }
while( ipos < m_FreeAssocArrp.GetSize() && m_FreeAssocArrp[ipos]->m_NonValidFree ) ;

const CLGAssoc* pAssocNext = NULL ;
if ( ipos < m_FreeAssocArrp.GetSize() )
    pAssocNext = m_FreeAssocArrp[ipos] ; // */

return pAssocNext;
}

//////////////////////////////////////////////////////////////////////////////
/// \brief
template<class KEY, class VALUE>
inline typename CLGMap<KEY, VALUE>::CLGPair*
CLGMap<KEY, VALUE>::PGetNextAssoc(const typename CLGMap<KEY, VALUE>::CLGPair* pPairRet)
{
CLGAssoc* pAssocRet = (CLGAssoc*)pPairRet;

//ASSERT(m_pHashTable != NULL);  // never call on empty map
//ASSERT(pAssocRet != NULL);

if(m_pHashTable == NULL || pAssocRet == NULL)
	return NULL;

ASSERT(pAssocRet != (CLGAssoc*)BEFORE_START_POSITION);

// find next association
//ASSERT(AfxIsValidAddress(pAssocRet, sizeof(CLGAssoc)));
CLGAssoc* pAssocNext;
if ((pAssocNext = pAssocRet->m_pNext) == NULL)
{
	// go to next bucket
	for (unsigned int nBucket = (pAssocRet->m_nHashValue % m_nHashTableSize) + 1;
	  nBucket < m_nHashTableSize; nBucket++)
		if ((pAssocNext = m_pHashTable[nBucket]) != NULL)
			break;
} // */

/* int ipos = pAssocRet->m_PosInFreeArrp ;

// on avance tant que pas valide
do  {
    ipos++ ;
    }
while( ipos < m_FreeAssocArrp.GetSize() && m_FreeAssocArrp[ipos]->m_NonValidFree ) ;

CLGAssoc* pAssocNext = NULL ;
if ( ipos < m_FreeAssocArrp.GetSize() )
    pAssocNext = m_FreeAssocArrp[ipos] ; // */

return pAssocNext;
}

/*****************************************************************************/

#define NB_ASSOC_IN_BLOCK_MAP_STRING  10

//////////////////////////////////////////////////////////////////////////////
/// \brief Classe qui associe une CLGString a une classe valeur
/// exemple : CLGMapStringTo<CLGArray<float>> Map ;
template<class VALUE>
class CLGMapStringTo
{
public:
	// CLGPair
	class CLGPair /// \brief paire key/value
        {
        public :
            CLGString m_key;
            VALUE     m_value;
        protected:
            CLGPair() {} ;
            CLGPair( const CLGString & keyval ) : m_key( keyval )	{}
        };

protected:
	// Association
	class CLGAssoc : public CLGPair /// \brief assocation pointeur next, haskey et CLGPair key/value
        {
            friend class CLGMapStringTo<VALUE>;
            friend class CLGAssocAssocBlock ;
            CLGAssoc*     m_pNext;
            unsigned int m_nHashValue;  // needed for efficient iteration
            //int          m_PosInFreeArrp ; ///< position dans le tableau de liberation
            bool          m_NonValidFree ;  ///< indique si la table est toujours valide dans la map ou si elle doit etre liberee

        public:
            CLGAssoc() {m_pNext=NULL;} ;
            CLGAssoc( const CLGString & key ) : CLGPair( key ) {m_pNext=NULL;}

            bool operator > ( const CLGAssoc & OtherClass ) const ;
            bool operator < ( const CLGAssoc & OtherClass ) const ;
        };

        /// \brief classe pour une allocation de CLGAssoc par packets (plus rapide)
    class CLGAssocAssocBlock
        {
        public :
            CLGAssocAssocBlock() { m_AssocArr = new CLGAssoc [NB_ASSOC_IN_BLOCK_MAP_STRING] ; } ;
            ~CLGAssocAssocBlock() { delete [] m_AssocArr ; }

            int        m_NbUsed = 0 ;  ///< nombre d'utilisé dans le packet
            CLGAssoc *  m_AssocArr ;    ///< tableau des packets

            /// \brief pour liberation du packet
            bool IsAllFree() const
                {
                int AllFree = true ;
                for ( int ia = 0 ; ia < m_NbUsed ; ia++ )
                    if ( ! m_AssocArr[ia].m_NonValidFree )
                        {
                        AllFree = false ;
                        break ;
                        }
                return AllFree ;
                }
        } ;

public:
// Construction
    explicit CLGMapStringTo( const CLGMapStringTo & );
	explicit CLGMapStringTo();

// Attributes
	// number of elements
	int GetCount() const;
	bool IsEmpty() const;

	// Lookup
	bool            Lookup(const CLGString & , VALUE& rValue) const;
	const CLGPair * PLookup(const CLGString & ) const;
	CLGPair *       PLookup(const CLGString & );

// Operations
	// Lookup and add if not there
	VALUE& operator[](const CLGString & );

	// add a new (key, value) pair
	void SetAt(const CLGString & , VALUE & newValue);

	// removing existing (key, ?) pair
	bool RemoveKey(const CLGString & );
	void RemoveAll();

	// iterating all (key, value) pairs
	POSITION GetStartPosition() const;

	const CLGPair *PGetFirstAssoc() const;
	CLGPair *PGetFirstAssoc();

	void GetNextAssoc(POSITION& rNextPosition, CLGString& rKey, VALUE& rValue) const;

	const CLGPair *PGetNextAssoc(const CLGPair *pAssocRet) const;
	CLGPair *PGetNextAssoc(const CLGPair *pAssocRet);

	// advanced features for derived classes
	unsigned int GetHashTableSize() const;
	void InitHashTable(unsigned int hashSize, bool bAllocNow = true );

	const CLGMapStringTo & operator = ( const CLGMapStringTo & Map ) ;

	void GetMinMaxMoyListe( int & Min , int & Max , float & Moy ) ;

    void CompressMap() ;
	void TriAdapte( bool Tri = TRI_CROISSANT ) ;
	void Shuffle() ;
    CLGPair * GetAt( int i )
        { return m_FreeAssocArrp[i] ; } ;
    const CLGPair * GetAt( int i ) const
        { return m_FreeAssocArrp[i] ; } ;
    int GetSizeFree() const
        { return m_FreeAssocArrp.GetSize() ; } ;

// Implementation
protected:
	CLGAssoc**    m_pHashTable;
	unsigned int m_nHashTableSize;
	int          m_nCount;

	CLGAssoc* NewAssoc(const CLGString & key);
	void      FreeAssoc(CLGAssoc*);
	CLGAssoc* GetAssocAt(const CLGString & , unsigned int&, unsigned int&) const;

	unsigned int HashKeyLGStringTo(const CLGString & ) const ;

public:
	~CLGMapStringTo();

private :
    CLGArrayPtr<CLGAssoc> m_FreeAssocArrp ; ///< toutes les associations de la vie de la map
    CLGArrayPtr<CLGAssocAssocBlock> m_AllocatedAssocBlockArrp ;///< tableau des block de CLGAssoc alloue pour optimization malloc
};

/*============================================================================*/
// CLGMapStringTo<CLGString, VALUE> inline functions

//////////////////////////////////////////////////////////////////////////////
/// \brief
template<class VALUE>
bool CLGMapStringTo<VALUE>::CLGAssoc::operator > ( const CLGMapStringTo<VALUE>::CLGAssoc & OtherClass ) const
{
return CLGMapStringTo<VALUE>::CLGAssoc::m_value > OtherClass.m_value ;
}

//////////////////////////////////////////////////////////////////////////////
/// \brief
template<class VALUE>
bool CLGMapStringTo<VALUE>::CLGAssoc::operator < ( const CLGMapStringTo<VALUE>::CLGAssoc & OtherClass ) const
{
return CLGMapStringTo<VALUE>::CLGAssoc::m_value < OtherClass.m_value ;
}

//////////////////////////////////////////////////////////////////////////////
/// \brief Compresse les clees detruites dans m_FreeAssocArrp puis fait un
/// FreeExtra.
template<class VALUE>
void CLGMapStringTo<VALUE>::CompressMap()
{
for ( int it = 0 ; it < m_FreeAssocArrp.GetSize() ; it ++ )
    if ( m_FreeAssocArrp[it]->m_NonValidFree )
        {
        //delete m_FreeAssocArrp[it] ;
        m_FreeAssocArrp[it] = NULL ;
        }

// compress null
m_FreeAssocArrp.CompressNull() ;
m_FreeAssocArrp.FreeExtra() ;

for ( int ia = 0 ; ia < m_AllocatedAssocBlockArrp.GetSize() ; ia++ )
    if ( m_AllocatedAssocBlockArrp[ia]->IsAllFree() )
        {
        delete m_AllocatedAssocBlockArrp[ia] ;
        m_AllocatedAssocBlockArrp[ia] = NULL ;
        }
m_AllocatedAssocBlockArrp.CompressNull() ;
m_AllocatedAssocBlockArrp.FreeExtra() ;
}

//////////////////////////////////////////////////////////////////////////////
/// \brief Tri le m_FreeAssocArrp pour un parcour croissant/decroissant
template<class VALUE>
void CLGMapStringTo<VALUE>::TriAdapte( bool Tri )
{
CompressMap() ;
m_FreeAssocArrp.TriAdapte( Tri ) ;
}

//////////////////////////////////////////////////////////////////////////////
/// \brief
template<class VALUE>
void CLGMapStringTo<VALUE>::Shuffle()
{
CompressMap() ;
m_FreeAssocArrp.Shuffle() ;
}

//////////////////////////////////////////////////////////////////////////////
/// \brief
template<class VALUE>
unsigned int CLGMapStringTo<VALUE>::HashKeyLGStringTo( const CLGString & key ) const
{
/*if (key == NULL)
    {
    cout << "NULL comme key dans CLGMapStringTo<VALUE>::HashKeyLGStringTo()" << endl ;
    ASSERT(1==0);
    }*/
if ( key.GetLength() == 0 || key == "" )
    {
    cout << "NULL comme key dans CLGMapStringTo<VALUE>::HashKeyLGStringTo()" << endl ;
    ASSERT(1==0);
    }

// hash key to UINT value by pseudorandomizing transform
// (algorithm copied from STL string hash in xfunctional)
unsigned int uHashVal = 2166136261U;
unsigned int uFirst = 0;
//unsigned int uLast = (unsigned int)strlen(key);
unsigned int uLast = (unsigned int)key.GetLength();
ASSERT( (unsigned int)key.GetLength() == (unsigned int)strlen(key) ) ;
unsigned int uStride = 1 + uLast / 10;
for(; uFirst < uLast; uFirst += uStride)
    uHashVal = 16777619U * uHashVal ^ (unsigned int)key[uFirst]; // */

/*unsigned int uHashVal ;
unsigned int Taille = strlen(key) ;
if ( Taille >= sizeof(int) )
    uHashVal = *((unsigned int*)key) ;
else if ( Taille >= sizeof(int) )
    uHashVal = *((unsigned int*)key) ;
else if ( Taille >= sizeof(short) )
    uHashVal = *((unsigned short*)key) ;
else
    {
    uHashVal = 0 ;
    for( unsigned int i = 0 ; i < Taille ; i++ )
        uHashVal += key[i] * (i+1) * 10 ;
    } // */

return(uHashVal);
}

//////////////////////////////////////////////////////////////////////////////
/// \brief Comme GetSize().
template<class VALUE>
int CLGMapStringTo<VALUE>::GetCount() const
	{ return m_nCount; }

//////////////////////////////////////////////////////////////////////////////
/// \brief Renseigne si la table est vide.
template<class VALUE>
bool CLGMapStringTo<VALUE>::IsEmpty() const
	{ return m_nCount == 0; }

//////////////////////////////////////////////////////////////////////////////
/// \brief Insere une nouvelle clee/valeur. Si la clee est deja presente, la
/// valeur est modifier.
template<class VALUE>
void CLGMapStringTo<VALUE>::SetAt(const CLGString & key, VALUE & newValue)
	{ (*this)[key] = newValue; }

//////////////////////////////////////////////////////////////////////////////
/// \brief Renvoi la debut de la CLGMap.
template<class VALUE>
POSITION CLGMapStringTo<VALUE>::GetStartPosition() const
	{ return (m_nCount == 0) ? NULL : BEFORE_START_POSITION; }

//////////////////////////////////////////////////////////////////////////////
/// \brief Renvoie un CLGPair * de la premierre association.
template<class VALUE>
const typename CLGMapStringTo<VALUE>::CLGPair* CLGMapStringTo<VALUE>::PGetFirstAssoc() const
{
if(m_nCount == 0) return NULL;

ASSERT(m_pHashTable != NULL);  // never call on empty map

CLGAssoc* pAssocRet = (CLGAssoc*)BEFORE_START_POSITION;

// find the first association
for (unsigned int nBucket = 0; nBucket < m_nHashTableSize; nBucket++)
	if ((pAssocRet = m_pHashTable[nBucket]) != NULL)
		break;
ASSERT(pAssocRet != NULL);  // must find something

return pAssocRet;
}

//////////////////////////////////////////////////////////////////////////////
/// \brief Renvoie un CLGPair * de la premierre association.
template<class VALUE>
typename CLGMapStringTo<VALUE>::CLGPair* CLGMapStringTo<VALUE>::PGetFirstAssoc()
{
if(m_nCount == 0) return NULL;

ASSERT(m_pHashTable != NULL);  // never call on empty map

CLGAssoc* pAssocRet = (CLGAssoc*)BEFORE_START_POSITION;

// find the first association
for (unsigned int nBucket = 0; nBucket < m_nHashTableSize; nBucket++)
	if ((pAssocRet = m_pHashTable[nBucket]) != NULL)
		break;
ASSERT(pAssocRet != NULL);  // must find something

return pAssocRet;
}

//////////////////////////////////////////////////////////////////////////////
/// \brief Renvoie la taille de la table de hachage.
template<class VALUE>
unsigned int CLGMapStringTo<VALUE>::GetHashTableSize() const
	{ return m_nHashTableSize; }

/*============================================================================*/
// CLGMap<CLGString, const char *, VALUE, ARG_VALUE> out-of-line functions

//////////////////////////////////////////////////////////////////////////////
/// \brief Constructeur.
template<class VALUE>
CLGMapStringTo<VALUE>::CLGMapStringTo()
{
m_pHashTable = NULL;
m_nHashTableSize = 17;  // default size
m_nCount = 0;
m_FreeAssocArrp.SetDeleteObjet(false) ;
m_AllocatedAssocBlockArrp.SetDeleteObjet(true) ;
}

//////////////////////////////////////////////////////////////////////////////
/// \brief Constructeur.
template<class VALUE>
CLGMapStringTo<VALUE>::CLGMapStringTo( const CLGMapStringTo<VALUE> & Map )
{
m_pHashTable = NULL ;
m_nHashTableSize = 17;  // default size
m_nCount = 0;
m_FreeAssocArrp.SetDeleteObjet(false) ;
m_AllocatedAssocBlockArrp.SetDeleteObjet(true) ;
*this = Map ;
}

//////////////////////////////////////////////////////////////////////////////
/// \brief operator de recopie
template<class VALUE>
const CLGMapStringTo<VALUE> & CLGMapStringTo<VALUE>::operator = ( const CLGMapStringTo<VALUE> & Map )
{
// si meme instance
if ( this == &Map )
    return *this ;

// destruction de tous
RemoveAll() ;

// init table de hashage
InitHashTable( Map.GetHashTableSize() , true ) ;

// recopie des donnees
const CLGMapStringTo<VALUE>::CLGPair * pPair = Map.PGetFirstAssoc() ;
while( pPair != NULL )
    {
    (*this)[pPair->m_key] = pPair->m_value ;
    pPair = Map.PGetNextAssoc( pPair ) ;
    }

// retour
return *this ;
}

//////////////////////////////////////////////////////////////////////////////
/// \brief Initialise la table de hachage (pour bien faire initialiser a taille
/// maximum + 20%).
template<class VALUE>
void CLGMapStringTo<VALUE>::InitHashTable(
	unsigned int nHashSize, bool bAllocNow)
//
// Used to force allocation of a hash table or to override the default
//   hash table size of (which is fairly small)
{
ASSERT(m_nCount == 0);
//ASSERT(nHashSize > 0);

if ( nHashSize < m_nHashTableSize )
    nHashSize = m_nHashTableSize ;

// positionne la croissance et force l'allocation immediate
ASSERT( m_FreeAssocArrp.GetSize() == 0 ) ;
/*m_FreeAssocArrp.SetGrow(nHashSize/10) ;
m_AllocatedAssocBlockArrp.SetDeleteObjet(true) ;
m_AllocatedAssocBlockArrp.SetGrow(nHashSize/(10*NB_ASSOC_IN_BLOCK));*/

if ( m_nCount > 0 )
    {
    cout << "InitHashTable() avec des donnees dedans !!!!" << endl ;
    RemoveAll() ;
    }

if (m_pHashTable != NULL)
	{
	// free hash table
	delete[] m_pHashTable;
	m_pHashTable = NULL;
	}

if (bAllocNow)
	{
	m_pHashTable = new CLGAssoc* [nHashSize];
	ASSERT(m_pHashTable != NULL);
	memset(m_pHashTable, 0, sizeof(CLGAssoc*) * nHashSize);
	}
m_nHashTableSize = nHashSize;
}

//////////////////////////////////////////////////////////////////////////////
/// \brief Vide la map.
template<class VALUE>
void CLGMapStringTo<VALUE>::RemoveAll()
{
#ifdef _LG_PROFIL_
int Min ;
int Max ;
float Moy ;
GetMinMaxMoyListe( Min , Max , Moy ) ;
if ( Moy > 1.9 )
    cout << "**** CLGMapStringTo<VALUE>::RemoveAll() min:" << Min << ", max:" << Max << ", Moy:" << Moy << ", count:" << GetCount() << ", hash:" << GetHashTableSize() << endl ;
#endif

if (m_pHashTable != NULL)
	{
    // free hash table
	delete[] m_pHashTable;
	m_pHashTable = NULL;
	}

m_nCount = 0;

m_FreeAssocArrp.DeleteAll() ;
m_AllocatedAssocBlockArrp.DeleteAll() ;
}

//////////////////////////////////////////////////////////////////////////////
/// \brief Destructeur.
template<class VALUE>
CLGMapStringTo<VALUE>::~CLGMapStringTo()
{
RemoveAll();
ASSERT(m_nCount == 0);
}

//////////////////////////////////////////////////////////////////////////////
/// \brief Creer une nouvelle assiciation key/value.
template<class VALUE>
typename CLGMapStringTo<VALUE>::CLGAssoc*
CLGMapStringTo<VALUE>::NewAssoc( const CLGString & key)
{
//CLGMapStringTo::CLGAssoc* pAssoc = new CLGAssoc(key) ;
CLGAssocAssocBlock *pAssocBloc ;
if ( m_AllocatedAssocBlockArrp.GetSize() == 0 )
    {
    m_AllocatedAssocBlockArrp.Add( pAssocBloc = new CLGAssocAssocBlock ) ;
    //pAssocBloc->m_AssocArr.SetSize(NB_ASSOC_IN_BLOCK,0) ;
    }
else
    pAssocBloc = m_AllocatedAssocBlockArrp[m_AllocatedAssocBlockArrp.GetUpperBound()] ;

if ( pAssocBloc->m_NbUsed >= NB_ASSOC_IN_BLOCK_MAP_STRING )
    {
    m_AllocatedAssocBlockArrp.Add( pAssocBloc = new CLGAssocAssocBlock ) ;
    //pAssocBloc->m_AssocArr.SetSize(NB_ASSOC_IN_BLOCK,0) ;
    }

//CLGMap::CLGAssoc* pAssoc = new CLGAssoc(key) ;
CLGMapStringTo::CLGAssoc* pAssoc = & pAssocBloc->m_AssocArr[ pAssocBloc->m_NbUsed++ ] ;
ASSERT( pAssocBloc->m_NbUsed <= NB_ASSOC_IN_BLOCK_MAP_STRING ) ;

m_FreeAssocArrp.Add( pAssoc ) ;

pAssoc->m_NonValidFree = false ;

pAssoc->m_key = key ;
//pAssoc->m_PosInFreeArrp = m_FreeAssocArrp.GetUpperBound() ;

m_nCount++;

// grow des tableau de pointeur vers les CLGAssoc et block de CLGAssoc
m_FreeAssocArrp.SetGrow( (m_nCount + m_nHashTableSize/4) / 2 ) ;
m_AllocatedAssocBlockArrp.SetGrow( (m_nCount + m_nHashTableSize/4) / (2*NB_ASSOC_IN_BLOCK_MAP_STRING) );

ASSERT(m_nCount > 0);  // make sure we don't overflow

return pAssoc;
}

//////////////////////////////////////////////////////////////////////////////
/// \brief Decompter le nombre d'element et positione m_NonValidFree.
template<class VALUE>
void CLGMapStringTo<VALUE>::FreeAssoc(CLGAssoc* pAssoc)
{
pAssoc->m_NonValidFree = true ;
m_nCount--;

ASSERT(m_nCount >= 0);  // make sure we don't underflow

// if no more elements, cleanup completely
if (m_nCount == 0)
	RemoveAll();
}

//////////////////////////////////////////////////////////////////////////////
/// \brief Renvoie le CLGAssoc a ma key.
/// \param nHashBucket[out] : position dans la table de haschage.
/// \param nHashValue[out] : valeur de la clee de haschage.
template<class VALUE>
typename CLGMapStringTo<VALUE>::CLGAssoc*
CLGMapStringTo<VALUE>::GetAssocAt(const CLGString & key, unsigned int& nHashBucket, unsigned int& nHashValue) const
// find association (or return NULL)
{
nHashValue = HashKeyLGStringTo(key);
nHashBucket = nHashValue % m_nHashTableSize;

if (m_pHashTable == NULL)
    return NULL;

	// see if it exists
CLGAssoc* pAssoc;
for ( pAssoc = m_pHashTable[nHashBucket]; pAssoc != NULL; pAssoc = pAssoc->m_pNext)
	{
	if (pAssoc->m_nHashValue == nHashValue && CompareElements(&pAssoc->m_key, &key))
		return pAssoc;
	}
return NULL;
}

//////////////////////////////////////////////////////////////////////////////
/// \brief Renvoie la valeur à la position key.
/// \return true si la clée est dans la map
template<class VALUE>
bool CLGMapStringTo<VALUE>::Lookup(const CLGString & key, VALUE& rValue) const
{
unsigned int nHashBucket, nHashValue;
CLGAssoc* pAssoc = GetAssocAt(key, nHashBucket, nHashValue);
if (pAssoc == NULL)
	return false;  // not in map

rValue = pAssoc->m_value;
return true;
}

//////////////////////////////////////////////////////////////////////////////
/// \brief Renvoie un CLGPair * a la clee key.
template<class VALUE>
const typename CLGMapStringTo<VALUE>::CLGPair* CLGMapStringTo<VALUE>::PLookup(const CLGString & key) const
{
unsigned int nHashBucket, nHashValue;
CLGAssoc* pAssoc = GetAssocAt(key, nHashBucket, nHashValue);
return pAssoc;
}

//////////////////////////////////////////////////////////////////////////////
/// \brief Renvoie un CLGPair * a la clee key.
template<class VALUE>
typename CLGMapStringTo<VALUE>::CLGPair* CLGMapStringTo<VALUE>::PLookup(const CLGString & key)
{
unsigned int nHashBucket, nHashValue;
CLGAssoc* pAssoc = GetAssocAt(key, nHashBucket, nHashValue);
return pAssoc;
}

//////////////////////////////////////////////////////////////////////////////
/// \brief Comme SetAt().
template<class VALUE>
VALUE& CLGMapStringTo<VALUE>::operator[](const CLGString & key)
{
#ifdef _LG_PROFIL_
if ( (int)GetCount() > (int)GetHashTableSize() )
    cout << "********** count : " << GetCount() << ", hashsize : " << GetHashTableSize() << " " << __FILE__ << " " << __LINE__ << endl ;
#endif

unsigned int nHashBucket, nHashValue;
CLGAssoc* pAssoc;
if ((pAssoc = GetAssocAt(key, nHashBucket, nHashValue)) == NULL)
	{
	if (m_pHashTable == NULL)
		InitHashTable(m_nHashTableSize);

	ASSERT(m_pHashTable);
	// it doesn't exist, add a new Association
	pAssoc = NewAssoc(key);
	pAssoc->m_nHashValue = nHashValue;
	//'pAssoc->m_value' is a constructed object, nothing more

	// put into hash table
	pAssoc->m_pNext = m_pHashTable[nHashBucket];
	m_pHashTable[nHashBucket] = pAssoc;
	}
return pAssoc->m_value;  // return new reference
}

//////////////////////////////////////////////////////////////////////////////
/// \brief Enleve l'element a la position clee.
template<class VALUE>
bool CLGMapStringTo<VALUE>::RemoveKey(const CLGString & key)
{
if (m_pHashTable == NULL)
	return false;  // nothing in the table

unsigned int nHashValue;
CLGAssoc** ppAssocPrev;
nHashValue = HashKeyLGStringTo(key);
ppAssocPrev = &m_pHashTable[nHashValue%m_nHashTableSize];

CLGAssoc* pAssoc;
for (pAssoc = *ppAssocPrev; pAssoc != NULL; pAssoc = pAssoc->m_pNext)
	{
	if ((pAssoc->m_nHashValue == nHashValue) && CompareElements(&pAssoc->m_key, &key))
		{
		// remove it
		*ppAssocPrev = pAssoc->m_pNext;  // remove from list
		FreeAssoc(pAssoc);
		return true;
		}
	ppAssocPrev = &pAssoc->m_pNext;
	}
return false;  // not found
}

//////////////////////////////////////////////////////////////////////////////
/// \brief Renvoi la prochaine position dans la map ainsi que la clee et valeur
/// courante.
template<class VALUE>
void CLGMapStringTo<VALUE>::GetNextAssoc(POSITION& rNextPosition,
	CLGString& rKey, VALUE& rValue) const
{
ASSERT(m_pHashTable != NULL);  // never call on empty map

CLGAssoc* pAssocRet = (CLGAssoc*)rNextPosition;
ASSERT(pAssocRet != NULL);

if (pAssocRet == (CLGAssoc*) BEFORE_START_POSITION)
	{
	// find the first association
	for (unsigned int nBucket = 0; nBucket < m_nHashTableSize; nBucket++)
		{
		if ((pAssocRet = m_pHashTable[nBucket]) != NULL)
			{
			break;
			}
		}
	ASSERT(pAssocRet != NULL);  // must find something
	}

// find next association
CLGAssoc* pAssocNext = NULL ;
if ((pAssocNext = pAssocRet->m_pNext) == NULL)
	{
	// go to next bucket
	for (unsigned int nBucket = (pAssocRet->m_nHashValue % m_nHashTableSize) + 1;
		  nBucket < m_nHashTableSize; nBucket++)
		if ((pAssocNext = m_pHashTable[nBucket]) != NULL)
			break;
	}

rNextPosition = (POSITION) pAssocNext;

// fill in return data
rKey = pAssocRet->m_key;
rValue = pAssocRet->m_value; // */

/*
CLGAssoc* pAssocRet = (CLGAssoc*)rNextPosition;
ASSERT(pAssocRet != NULL);
ASSERT( GetCount() > 0 ) ;

int ipos ;
// si debut de la boucle
if (pAssocRet == (CLGAssoc*) BEFORE_START_POSITION)
    {
    ipos = 0 ;
    // recherche du premier valide
    while( ipos < m_FreeAssocArrp.GetSize() && m_FreeAssocArrp[ipos]->m_NonValidFree )
        ipos ++ ;
    pAssocRet = (CLGAssoc*) m_FreeAssocArrp[ipos] ;
    }
else
    ipos = pAssocRet->m_PosInFreeArrp ;

ASSERT( ipos >= 0 ) ;
ASSERT( ipos < m_FreeAssocArrp.GetSize() ) ;

// on avance tant que pas valide
do  {
    ipos++ ;
    }
while( ipos < m_FreeAssocArrp.GetSize() && m_FreeAssocArrp[ipos]->m_NonValidFree ) ;

// prochaine position
if ( ipos < m_FreeAssocArrp.GetSize() )
    rNextPosition = (POSITION) m_FreeAssocArrp[ipos] ;
else
    rNextPosition = NULL ;

// fill in return data
rKey   = pAssocRet->m_key;
rValue = pAssocRet->m_value; */
}

//////////////////////////////////////////////////////////////////////////////
/// \brief Renvoie la prochaine association clee/valeur
template<class VALUE>
const typename CLGMapStringTo<VALUE>::CLGPair*
CLGMapStringTo<VALUE>::PGetNextAssoc(const typename CLGMapStringTo<VALUE>::CLGPair* pPairRet) const
{
CLGAssoc* pAssocRet = (CLGAssoc*)pPairRet;

ASSERT(m_pHashTable != NULL);  // never call on empty map
ASSERT(pAssocRet != NULL);

if( m_pHashTable == NULL || pAssocRet == NULL)
    return NULL;

ASSERT(pAssocRet != (CLGAssoc*)BEFORE_START_POSITION);

// find next association
CLGAssoc* pAssocNext = NULL ;
if ( (pAssocNext = pAssocRet->m_pNext) == NULL)
	{
	// go to next bucket
	for (unsigned int nBucket = (pAssocRet->m_nHashValue % m_nHashTableSize) + 1;
		  nBucket < m_nHashTableSize; nBucket++)
		if ((pAssocNext = m_pHashTable[nBucket]) != NULL)
			break;
	} // */

/*int ipos = pAssocRet->m_PosInFreeArrp ;

// on avance tant que pas valide
do  {
    ipos++ ;
    }
while( ipos < m_FreeAssocArrp.GetSize() && m_FreeAssocArrp[ipos]->m_NonValidFree ) ;

const CLGAssoc* pAssocNext = NULL ;
if ( ipos < m_FreeAssocArrp.GetSize() )
    pAssocNext = m_FreeAssocArrp[ipos] ; // */

return pAssocNext;
}

//////////////////////////////////////////////////////////////////////////////
/// \brief Renvoie la prochaine association clee/valeur
template<class VALUE>
typename CLGMapStringTo<VALUE>::CLGPair*
CLGMapStringTo<VALUE>::PGetNextAssoc(const typename CLGMapStringTo<VALUE>::CLGPair* pPairRet)
{
CLGAssoc* pAssocRet = (CLGAssoc*)pPairRet;

ASSERT(m_pHashTable != NULL);  // never call on empty map
ASSERT(pAssocRet != NULL);

if(m_pHashTable == NULL || pAssocRet == NULL)
	return NULL;

ASSERT(pAssocRet != (CLGAssoc*)BEFORE_START_POSITION);

// find next association
CLGAssoc* pAssocNext = NULL ;
if ( (pAssocNext = pAssocRet->m_pNext) == NULL)
	{
	// go to next bucket
	for (unsigned int nBucket = (pAssocRet->m_nHashValue % m_nHashTableSize) + 1;
		  nBucket < m_nHashTableSize; nBucket++)
        if ((pAssocNext = m_pHashTable[nBucket]) != NULL)
			break;
	} // */

/* int ipos = pAssocRet->m_PosInFreeArrp ;

// on avance tant que pas valide
do  {
    ipos++ ;
    }
while( ipos < m_FreeAssocArrp.GetSize() && m_FreeAssocArrp[ipos]->m_NonValidFree ) ;

CLGAssoc* pAssocNext = NULL ;
if ( ipos < m_FreeAssocArrp.GetSize() )
    pAssocNext = m_FreeAssocArrp[ipos] ; // */

return pAssocNext;
}

//////////////////////////////////////////////////////////////////////////////
/// \brief Renoie le mininmum/maximum/moyenne de profondeur de liste chainee
template<class VALUE>
void CLGMapStringTo<VALUE>::GetMinMaxMoyListe( int & Min , int & Max , float & Moy )
{
if ( GetCount() == 0 || m_pHashTable == NULL )
    {
    Min = Max = Moy = 0 ;
    return ;
    }

int NbListe = 0 ;
Moy = 0 ;
Min = LONG_MAX ;
Max = -LONG_MAX ;

CLGAssoc * pAssoc ;
for (unsigned int nBucket = 0; nBucket < m_nHashTableSize; nBucket++)
    {
	if ((pAssoc = m_pHashTable[nBucket]) != NULL)
        {
        NbListe++ ;
        int Count = 0 ;
        while( pAssoc != NULL )
            {
            Count++ ;
            pAssoc = pAssoc->m_pNext ;
            }
        Min = MIN( Min , Count ) ;
        Max = MAX( Max , Count ) ;
        Moy += Count ;
        }
	}
if ( NbListe > 0 )
    Moy /= NbListe ;
}

#endif
