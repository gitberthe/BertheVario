///////////////////////////////////////////////////////////////////////////////
/// \file CLGLObjets.h
/// \date 23/03/2002 : date de creation
/// \addtogroup LibGeneral
/// \brief CLGLObjets
///
/// \date 21/09/2004 : Creation de la classe CLGNode.
/// \date 05/09/2023 : Derniere modification.
///

#ifndef __CLISTOBJECTS_H__
#define __CLISTOBJECTS_H__

/////////////////////////////////////////////////////////////////////////////
/// \brief Noeud de base pour CLGLObjets.
template <class T>
class CLGNode
{
public :
    CLGNode()
        { m_pNext = m_pPrev = NULL ; } ;
    CLGNode*  m_pNext;
    CLGNode*  m_pPrev;
    T  m_data;
};

//struct CLG__POSITION { };
//typedef CLG__POSITION* POSITION;

/////////////////////////////////////////////////////////////////////////////
/// \brief Classe de base pour les listes chainées de template (utilise des CLGNode).
template <class T>
class CLGLObjets
{
public:

// Construction
    CLGLObjets();

// Attributes (head and tail)
    // count of elements
    int     GetCount() const
                { return m_nCount; }
    int    IsEmpty() const
                { return m_nCount == 0; }

    // peek at head or tail
    T & GetHead()
                { ASSERT(m_pNodeHead != NULL);
                    return m_pNodeHead->m_data; }
    const T & GetHead() const
                { ASSERT(m_pNodeHead != NULL);
                    return m_pNodeHead->m_data; }
    T& GetTail()
                { ASSERT(m_pNodeTail != NULL);
                    return m_pNodeTail->m_data; }
    const T & GetTail() const
                { ASSERT(m_pNodeTail != NULL);
                    return m_pNodeTail->m_data; }

// Operations
    // get head or tail (and remove it) - don't call on empty list !
    T    RemoveHead();
    T    RemoveTail();

    // add before head or after tail
    CLGNode<T>* AddHead( const T & newElement);
    CLGNode<T>* AddTail( const T & newElement);

    // add another list of elements before head or after tail
    void    AddHead( const CLGLObjets & pNewList);
    void    AddTail( const CLGLObjets & pNewList);

    // remove all elements
    void    RemoveAll();

    // iteration
    CLGNode<T>* GetHeadPosition() const
                { return (CLGNode<T>*) m_pNodeHead; }
    CLGNode<T>* GetTailPosition() const
                { return (CLGNode<T>*) m_pNodeTail; }
    T & GetNext(CLGNode<T>*& rPosition) // return *Position++
                { CLGNode<T>* pNode = (CLGNode<T>*) rPosition;
                    ASSERT(pNode != NULL);
                    rPosition = (CLGNode<T>*) pNode->pNext;
                    return pNode->data; }
    const T & GetNext(CLGNode<T>*& rPosition) const // return *Position++
                { CLGNode<T>* pNode = (CLGNode<T>*) rPosition;
                    ASSERT(pNode != NULL);
                    rPosition = (CLGNode<T>*) pNode->pNext;
                    return pNode->data; }
    T & GetPrev(CLGNode<T>*& rPosition) // return *Position--
                { CLGNode<T>* pNode = (CLGNode<T>*) rPosition;
                    ASSERT(pNode != NULL);
                    rPosition = (CLGNode<T>*) pNode->pPrev;
                    return pNode->data; }
    const T & GetPrev(CLGNode<T>*& rPosition) const // return *Position--
                { CLGNode<T>* pNode = (CLGNode<T>*) rPosition;
                    ASSERT(pNode != NULL);
                    rPosition = (CLGNode<T>*) pNode->pPrev;
                    return pNode->data; }

    // getting/modifying an element at a given position
    T& GetAt(CLGNode<T>* position)
                { CLGNode<T>* pNode = (CLGNode<T>*) position;
                    ASSERT(pNode != NULL);
                    return pNode->data; }
    const T & GetAt(CLGNode<T>* position) const
                { CLGNode<T>* pNode = (CLGNode<T>*) position;
                    ASSERT(pNode != NULL);
                    return pNode->data; }
    void    SetAt(CLGNode<T>* pos, const T & newElement)
                { CLGNode<T>* pNode = (CLGNode<T>*) pos;
                    ASSERT(pNode != NULL);
                    pNode->data = & newElement; }
    void    RemoveAt(CLGNode<T>* position);

    // inserting before or after a given position
    CLGNode<T>* InsertBefore(CLGNode<T>* position, const T & newElement);
    CLGNode<T>* InsertAfter(CLGNode<T>* position, const T & newElement);

    // helper functions (note: O(n) speed)
    CLGNode<T>* Find( const T & searchValue, CLGNode<T>* startAfter = NULL) const;
                        // defaults to starting at the HEAD
                        // return NULL if not found
    CLGNode<T>* FindIndex(int nIndex) const;
                        // get the 'nIndex'th element (may return NULL)

// Implementation
protected:
    CLGNode<T>*  m_pNodeHead;
    CLGNode<T>*  m_pNodeTail;
    int     m_nCount;

    CLGNode<T>*  NewNode(CLGNode<T>*, CLGNode<T>*);
    void    FreeNode(CLGNode<T>*);

public:
    ~CLGLObjets();
};

#include "CLGLObjets_inl.h"

#endif //__CLISTOBJECTS_H__
