//////////////////////////////////////////////////////////////////////////////
/// \file CLGMap.cpp
/// \date 07/06/2020 : Date de creation
///
/// \brief Fichier de d'implementation de CLGMap .
///
/// \date 24/12/2022 : derniere modification.
///

#include "LibGeneral.h"

/*
//////////////////////////////////////////////////////////////////////////////
/// \brief Cree un block pour stocker des CLGAssoc en nMax fois.
CLGPlex* CLGPlex::Create(CLGPlex*& pHead, unsigned int nMax, unsigned int cbElement)
{
	ASSERT(nMax > 0 && cbElement > 0);
	if (nMax == 0 || cbElement == 0)
        {
		//AfxThrowInvalidArgException();
		ASSERT(1==0) ;
        }

	//CLGPlex* p = (CLGPlex*) new BYTE[sizeof(CLGPlex) + nMax * cbElement];
	CLGPlex* p = (CLGPlex*) new unsigned char[sizeof(CLGPlex) + nMax * cbElement];

    // may throw exception
    // on modifie la tete de chainage (m_pBlocks)
	p->pNext = pHead;
	pHead = p;  // change head (adds in reverse order for simplicity)
	return p;
}

//////////////////////////////////////////////////////////////////////////////
/// \brief Libere tous les CLGAssoc allouer durant la vie de la CMap.
void CLGPlex::FreeDataChain()     // free this one and links
{
	CLGPlex* p = this;
	while (p != NULL)
        {
		//BYTE* bytes = (BYTE*) p;
		unsigned char* bytes = (unsigned char*) p;
		CLGPlex* pNext = p->pNext;
		delete [] bytes;
		p = pNext;
        }
}
*/

//////////////////////////////////////////////////////////////////////////////
/// \brief Fonction pour tester les CLGMap et CLGMapStringTo
void TestMap()
{
bool TestOk = true ;
CLGMap<int , CLGString > MapLtoS ;

MapLtoS.InitHashTable(100) ;
ASSERT( MapLtoS.GetHashTableSize() == 100 ) ;

// operator []
for ( int i = 0 ; i < 1000 ; i++ )
    {
    CLGString LGSData ;
    LGSData.Format("%ld",i+1) ;
    MapLtoS[i] = LGSData ;
    }
// SetAt
for ( int i = 1000 ; i < 1500 ; i++ )
    {
    CLGString LGSData ;
    LGSData.Format("%ld",i+1) ;
    MapLtoS.SetAt(i,LGSData) ;
    }
// LookUp
for ( int i = 0 ; i < 1500 ; i++ )
    {
    CLGString LGSData ;
    MapLtoS.Lookup(i,LGSData) ;
    int valeur = atol(LGSData) ;
    int index  = i ;
    if ( (index+1) != valeur )
        {
        TestOk = false ;
        cout << "**** erreur donnees LookUp" << i << "/" << (const char*)LGSData << endl ;
        }
    }
// PLookUp
for ( int i = 0 ; i < 1500 ; i++ )
    {
    CLGString LGSDataTheorique ;
    LGSDataTheorique.Format("%ld",i+1) ;
    auto Pair = MapLtoS.PLookup(i) ;
    if ( Pair->m_key != i || Pair->m_value != LGSDataTheorique )
        {
        TestOk = false ;
        cout << "**** erreur donnees PLookUp" << Pair->m_key << "/" << (const char*)LGSDataTheorique << endl ;
        }
    }

// RemoveKey
for ( int i = 1000 ; i < 1500 ; i++ )
    {
    if ( !MapLtoS.RemoveKey(i) )
       cout << "**** erreur RemoveKey() : " << i << endl ;
    }
// test taille
if ( MapLtoS.GetCount() != 1000 )
    {
    TestOk = false ;
    cout << "**** erreur taille " << MapLtoS.GetCount() << endl ;
    }

// parcour de la map avec Position
POSITION pos = MapLtoS.GetStartPosition() ;
while ( pos != NULL )
    {
    //CLGString LGSIndex ;
    int i ;
    CLGString LGSData ;
    MapLtoS.GetNextAssoc(pos,i,LGSData) ;
    int valeur = atol(LGSData) ;
    int index  = i ;
    if ( (index+1) != valeur )
        {
        TestOk = false ;
        cout << "**** erreur donnees GetNextAssoc" << i << "/" << (const char*)LGSData << endl ;
        }
    }

// parcour de la map avec CPair
auto PairLtoS = MapLtoS.PGetFirstAssoc() ;
while( PairLtoS != NULL )
    {
    CLGString LGSDataTheorique ;
    LGSDataTheorique.Format("%ld",PairLtoS->m_key+1) ;
    if ( LGSDataTheorique != PairLtoS->m_value )
        {
        TestOk = false ;
        cout << "**** erreur donnees PGetNextAssoc" << PairLtoS->m_value << "/" << (const char*)LGSDataTheorique << endl ;
        }
    PairLtoS = MapLtoS.PGetNextAssoc(PairLtoS) ;
    }

int i = 10 ;
CLGString a ; //= Map["1"] ;
MapLtoS.Lookup(i,a);

if ( TestOk )
    cout << "test CLGMap ok (11): " << a << endl ;
MapLtoS.RemoveAll() ;
cout << "taille 0 CLGMap : " << MapLtoS.GetCount() << endl ;
ASSERT( MapLtoS.IsEmpty() ) ;

/*****************************************************************************/

CLGMapStringTo<CLGString> MapStoS ;

MapStoS.InitHashTable(100) ;
ASSERT( MapStoS.GetHashTableSize() == 100 ) ;

// operator []
for ( int i = 0 ; i < 1000 ; i++ )
    {
    CLGString LGSIndex ;
    LGSIndex.Format("%ld",i) ;
    CLGString LGSData ;
    LGSData.Format("%ld",i+1) ;
    MapStoS[LGSIndex] = LGSData ;
    }
// SetAt
for ( int i = 1000 ; i < 1500 ; i++ )
    {
    CLGString LGSIndex ;
    LGSIndex.Format("%ld",i) ;
    CLGString LGSData ;
    LGSData.Format("%ld",i+1) ;
    MapStoS.SetAt(LGSIndex,LGSData) ;
    }
// LookUp
for ( int i = 0 ; i < 1500 ; i++ )
    {
    CLGString LGSIndex ;
    LGSIndex.Format("%ld",i) ;
    CLGString LGSData ;
    MapStoS.Lookup(LGSIndex,LGSData) ;
    int valeur = atol(LGSData) ;
    int index  = atol(LGSIndex) ;
    if ( (index+1) != valeur )
        {
        TestOk = false ;
        cout << "**** erreur donnees LookUp" << (const char*)LGSIndex << "/" << (const char*)LGSData << endl ;
        }
    }
// PLookUp
for ( int i = 0 ; i < 1500 ; i++ )
    {
    CLGString LGSIndex ;
    LGSIndex.Format("%ld",i) ;
    CLGString LGSDataTheorique ;
    LGSDataTheorique.Format("%ld",i+1) ;
    auto Pair = MapStoS.PLookup(LGSIndex) ;
    if ( Pair == NULL || Pair->m_key != LGSIndex || Pair->m_value != LGSDataTheorique )
        {
        TestOk = false ;
        cout << "**** erreur donnees PLookUp" << (const char*)LGSDataTheorique << endl ;
        }
    }

// RemoveKey
for ( int i = 1000 ; i < 1500 ; i++ )
    {
    CLGString LGSIndex ;
    LGSIndex.Format("%ld",i) ;
    if ( !MapStoS.RemoveKey(LGSIndex) )
       cout << "**** erreur RemoveKey() : " << i << endl ;
    }
// test taille
if ( MapStoS.GetCount() != 1000 )
    {
    TestOk = false ;
    cout << "**** erreur taille " << MapStoS.GetCount() << endl ;
    }

// parcour de la map avec Position
pos = MapStoS.GetStartPosition() ;
while ( pos != NULL )
    {
    CLGString LGSIndex ;
    CLGString LGSData ;
    MapStoS.GetNextAssoc(pos,LGSIndex,LGSData) ;
    int valeur = atol(LGSData) ;
    int index  = atol(LGSIndex) ;
    if ( (index+1) != valeur )
        {
        TestOk = false ;
        cout << "**** erreur donnees GetNextAssoc" << i << "/" << (const char*)LGSData << endl ;
        }
    }

// parcour de la map avec CPair
auto PairStoS = MapStoS.PGetFirstAssoc() ;
while( PairStoS != NULL )
    {
    CLGString LGSDataTheorique ;
    LGSDataTheorique.Format("%ld",atol(PairStoS->m_key)+1) ;
    if ( LGSDataTheorique != PairStoS->m_value )
        {
        TestOk = false ;
        cout << "**** erreur donnees PGetNextAssoc" << (const char*)PairStoS->m_value << "/" << (const char*)LGSDataTheorique << endl ;
        }
    PairStoS = MapStoS.PGetNextAssoc(PairStoS) ;
    }

CLGString LGSIndex ;
LGSIndex.Format("%ld",10) ;
MapStoS.Lookup(LGSIndex,a);

if ( TestOk )
    cout << "test CLGMapLGStringTo ok (11): " << a << endl ;
MapStoS.RemoveAll() ;
cout << "taille 0 CLGMapLGStringTo : " << MapStoS.GetCount() << endl ;
ASSERT( MapStoS.IsEmpty() ) ;

/*****************************************************************************/
CLGMap<int,CLGArrayPtr<int>> MapLtoA ;

for ( int i = 0 ; i < 100 ; i++ )
    {
    CLGArrayPtr<int> & PtrArr = MapLtoA[i] ;
    PtrArr.Add((int*)1) ;
    PtrArr.Add((int*)2) ;
    PtrArr.Add((int*)3) ;
    }

MapLtoA.RemoveAll() ;
}

