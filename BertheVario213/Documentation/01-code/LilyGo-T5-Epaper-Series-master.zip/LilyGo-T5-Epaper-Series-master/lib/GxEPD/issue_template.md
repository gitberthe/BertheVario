### Please post only issues that errors in this library!
- please use the Arduino Forum Displays for questions or enhancement suggestions

#### Version number of the library used, should be the current one
- this number is needed for later reference and tracking

#### Expected Behavior

#### Actual Behavior

#### E-Paper module used

#### Arduino / Processor module used

#### Steps to reproduce the behavior or reduced but complete code example
