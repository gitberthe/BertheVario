////////////////////////////////////////////////////////////////////////////////
/// \file CNbSatDelay.cpp
///
/// \brief
///
/// \date creation     : 12/10/2024
/// \date modification : 14/10/2025 m_sat_sec < 4 .
/// \date 19/10/2025 : introduction du HDop
///

#include "../BertheVario.h"

////////////////////////////////////////////////////////////////////////////////
/// \brief Renvoi le temps en secondes d'attente apres un changement de nombre
/// de satellites en vue. Prend en compte le HDop.
/// \return m_sat_sec : si 4 satellites.
/// \return 0 : si 30 satellites.
int CNbSatDelay::GetSatDelay() const
{
/*
// si plus que 3 satellites
if ( NbSat < 4 )
    NbSat = 4 ;
// calcul du delay
float SecDelay = ((float)(m_sat_sec))*((float)(30.-NbSat))/26. ;
if ( SecDelay < 0. )
    SecDelay = 0. ;
*/

// ajout du HDop
float SatDelay = 1. + 3. * CTrame::GetHDop() ;  ///< de 1 a 8
Serial.print( "SatDelay : " ) ;
Serial.println( SatDelay , 1 ) ;
return (int)SatDelay ;
}
