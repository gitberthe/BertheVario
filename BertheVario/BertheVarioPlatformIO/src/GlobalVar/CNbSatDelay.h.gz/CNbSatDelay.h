////////////////////////////////////////////////////////////////////////////////
/// \file CNbSatDelay.h
///
/// \brief
///
/// \date creation     : 12/10/2024
/// \date modification : 15/10/2024
///

#ifndef _NBSATDELAY_
#define _NBSATDELAY_

////////////////////////////////////////////////////////////////////////////////
/// \brief Temps d'attente decroissant avec le nombre de satelittes en vue.
class CNbSatDelay
{
public :
    int GetSatDelay() const ;

protected :
    //int   m_sat_sec = 12 ; ///< secondes d'interdiction debut vol vitesse cause changement nombre satellites (pour 4 satelites)
} ;

#endif
