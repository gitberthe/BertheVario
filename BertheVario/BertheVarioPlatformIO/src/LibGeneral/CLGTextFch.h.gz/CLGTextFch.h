//////////////////////////////////////////////////////////////////////////////
/// \file   CLGTextFch.h
/// \date   20/05/2003 : date de creation
/// \addtogroup LibGeneral
/// \brief CLGTextFch
///
/// \date  21/05/2022 : Derniere modification.
///

#ifndef __FICHIER_TEXTE_H__
#define __FICHIER_TEXTE_H__

#define DEFAULT_LONG_LIGNE_MAX 500000
#define SIZE_BUFFER_READ       1024*128

//////////////////////////////////////////////////////////////////////
/// \brief classe de base pour lire/ecrire un fichier texte.
///
/// Cette classe est utilisee pour lire un fichier de cometes, asteroides,
/// sexe...
///
class CLGTextFch
{
public :
    CLGTextFch( const char * NomFichier = NULL /*, int GrowBy = 50*/ ) ;
    ~CLGTextFch() ;

    void SetNom( const char * NomFichier ) ;
    const char * GetNom() ;

    short Read() ;
    short Write() ;
    void  Clear() ;

    int  GetLonLigneMax() const     { return m_LongLigneMax ; } ;
    void        SetLongLigneMax( int LongLigneMax /*, int GrowBy = -1 */) ;
    CLGString &       ElementAt( int i )
            { return *m_TabLigne[i] ; } ;
    const CLGString & GetAt( int i ) const
            { return *m_TabLigne[i] ; } ;
    int              GetSize()       const
            { return m_TabLigne.GetSize() ; } ;
    CLGString & operator [] (int i)
            { return *m_TabLigne[i] ; } ;
    const CLGString & operator [] (int i) const
            { return *m_TabLigne[i] ; } ;
    void Add( const char * p )
            { CLGString * ps = new CLGString(p) ;
              m_TabLigne.Add(ps) ; } ;
    void CompressNull()
        { m_TabLigne.CompressNull() ; };
    void SetNullAt(int i)
        {
        delete m_TabLigne[i] ;
        m_TabLigne[i] = NULL ;
        }

private :
    CLGString m_NomFichier ;
    int      m_LongLigneMax ;
    CLGArrayPtr< CLGString > m_TabLigne ;
} ;

#endif // __FICHIER_TEXTE_H__
