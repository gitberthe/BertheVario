//////////////////////////////////////////////////////////////////////////////
/// \file   CLGLObjets_inl.h
/// \date   19/01/2001 : date de creation
///
/// \brief Implementation de CLGLObjets.
///
/// \date 21/09/2004 : Creation de la classe CLGNode.
/// \date 23/05/2020 : Derniere modification.
///

//////////////////////////////////////////////////////////////////////
//
template <class T>
inline CLGLObjets< T >::CLGLObjets()
{
m_nCount = 0;
m_pNodeHead = m_pNodeTail = NULL;
}

//////////////////////////////////////////////////////////////////////
//
template <class T>
inline void CLGLObjets< T >::RemoveAll()
{
while( ! IsEmpty() )
    RemoveHead() ;
}

//////////////////////////////////////////////////////////////////////
//
template <class T>
inline CLGLObjets< T >::~CLGLObjets()
{
RemoveAll();
ASSERT(m_nCount == 0);
}

//////////////////////////////////////////////////////////////////////
//
template <class T>
inline CLGNode<T>*
CLGLObjets< T >::NewNode( CLGNode<T>* pPrev, CLGNode<T>* pNext)
{
CLGNode<T>* pNode = new CLGNode<T> ;
pNode->m_pPrev = pPrev;
pNode->m_pNext = pNext;
m_nCount++;
ASSERT(m_nCount > 0);       // make sure we don't overflow
return pNode;
}

//////////////////////////////////////////////////////////////////////
//
template <class T>
inline void CLGLObjets< T >::FreeNode( CLGNode<T>* pNode)
{
delete pNode ;
m_nCount--;
ASSERT(m_nCount >= 0);      // make sure we don't underflow
}

//////////////////////////////////////////////////////////////////////
//
template <class T>
inline CLGNode<T>* CLGLObjets< T >::AddHead( const T & newElement)
{
CLGNode<T>* pNewNode = NewNode(NULL, m_pNodeHead);
pNewNode->m_data = newElement;
if (m_pNodeHead != NULL)
    m_pNodeHead->m_pPrev = pNewNode;
else
    m_pNodeTail = pNewNode;
m_pNodeHead = pNewNode;
return (CLGNode<T>*) pNewNode;
}


//////////////////////////////////////////////////////////////////////
//
template <class T>
inline CLGNode<T>* CLGLObjets< T >::AddTail( const T & newElement)
{
CLGNode<T>* pNewNode = NewNode(m_pNodeTail, NULL);
pNewNode->m_data = newElement;
if (m_pNodeTail != NULL)
    m_pNodeTail->m_pNext = pNewNode;
else
    m_pNodeHead = pNewNode;
m_pNodeTail = pNewNode;
return (CLGNode<T>*) pNewNode;
}


//////////////////////////////////////////////////////////////////////
//
template <class T>
inline void CLGLObjets< T >::AddHead( const CLGLObjets & pNewList)
{
ASSERT(pNewList != NULL);

// add a list of same elements to head (maintain order)
CLGNode<T>* pos = pNewList->GetTailPosition();
while (pos != NULL)
    AddHead(pNewList->GetPrev(pos));
}


//////////////////////////////////////////////////////////////////////
//
template <class T>
inline void CLGLObjets< T >::AddTail( const CLGLObjets & pNewList)
{
ASSERT(pNewList != NULL);

// add a list of same elements
CLGNode<T>* pos = pNewList->GetHeadPosition();
while (pos)
    AddTail(pNewList->GetNext(pos));
}


//////////////////////////////////////////////////////////////////////
//
template <class T>
inline T CLGLObjets< T >::RemoveHead()
{
ASSERT(m_pNodeHead != NULL);    // don't call on empty list !!!

CLGNode<T>* pOldNode = m_pNodeHead;
ASSERT(pOldNode != NULL);
T returnValue = pOldNode->m_data;

m_pNodeHead = pOldNode->m_pNext;
if (m_pNodeHead != NULL)
    m_pNodeHead->m_pPrev = NULL;
else
    m_pNodeTail = NULL;
FreeNode(pOldNode);
return returnValue;
}


//////////////////////////////////////////////////////////////////////
//
template <class T>
inline T CLGLObjets< T >::RemoveTail()
{
ASSERT(m_pNodeTail != NULL);    // don't call on empty list !!!

CLGNode<T>* pOldNode = m_pNodeTail;
ASSERT(pOldNode != NULL);
T returnValue = pOldNode->m_data;

m_pNodeTail = pOldNode->m_pPrev;
if (m_pNodeTail != NULL)
    m_pNodeTail->m_pNext = NULL;
else
    m_pNodeHead = NULL;
FreeNode(pOldNode);
return returnValue;
}


//////////////////////////////////////////////////////////////////////
//
template <class T>
inline CLGNode<T>* CLGLObjets< T >::InsertBefore(CLGNode<T>* position, const T & newElement)
{
if (position == NULL)
    return AddHead(newElement); // insert before nothing -> head of the list

// Insert it before position
CLGNode<T>* pOldNode = (CLGNode<T>*) position;
CLGNode<T>* pNewNode = NewNode(pOldNode->m_pPrev, pOldNode);
pNewNode->m_data = newElement;

if (pOldNode->m_pPrev != NULL)
    {
    pOldNode->m_pPrev->m_pNext = pNewNode;
    }
else
    {
    ASSERT(pOldNode == m_pNodeHead);
    m_pNodeHead = pNewNode;
    }
pOldNode->m_pPrev = pNewNode;
return (CLGNode<T>*) pNewNode;
}


//////////////////////////////////////////////////////////////////////
//
template <class T>
inline CLGNode<T>* CLGLObjets< T >::InsertAfter(CLGNode<T>* position, const T & newElement)
{
if (position == NULL)
    return AddTail(newElement); // insert after nothing -> tail of the list

// Insert it before position
CLGNode<T>* pOldNode = (CLGNode<T>*) position;
CLGNode<T>* pNewNode = NewNode(pOldNode, pOldNode->m_pNext);
pNewNode->m_data = newElement;

if (pOldNode->m_pNext != NULL)
    {
    pOldNode->m_pNext->m_pPrev = pNewNode;
    }
else
    {
    ASSERT(pOldNode == m_pNodeTail);
    m_pNodeTail = pNewNode;
    }
pOldNode->m_pNext = pNewNode;
return (CLGNode<T>*) pNewNode;
}


//////////////////////////////////////////////////////////////////////
//
template <class T>
inline void CLGLObjets< T >::RemoveAt(CLGNode<T>* position)
{
ASSERT(position != NULL);

CLGNode<T>* pOldNode = (CLGNode<T>*) position;

// remove pOldNode from list
if (pOldNode == m_pNodeHead)
    m_pNodeHead = pOldNode->m_pNext;
else
    pOldNode->m_pPrev->m_pNext = pOldNode->m_pNext;
if (pOldNode == m_pNodeTail)
    m_pNodeTail = pOldNode->m_pPrev;
else
    pOldNode->m_pNext->m_pPrev = pOldNode->m_pPrev;
FreeNode(pOldNode);
}

//////////////////////////////////////////////////////////////////////
//
template <class T>
inline CLGNode<T>* CLGLObjets< T >::FindIndex(int nIndex) const
{
ASSERT(nIndex >= 0);

if (nIndex >= m_nCount)
    return NULL;        // went too far

CLGNode<T>* pNode = m_pNodeHead;
while (nIndex--)
    pNode = pNode->m_pNext;
return (CLGNode<T>*) pNode;
}


//////////////////////////////////////////////////////////////////////
//
template <class T>
inline CLGNode<T>* CLGLObjets< T >::Find( const T & searchValue, CLGNode<T>* startAfter) const
{
CLGNode<T>* pNode = (CLGNode<T>*) startAfter;
if (pNode == NULL)
    pNode = m_pNodeHead;        // start at head
else
    pNode = pNode->m_pNext;       // start after the one specified

for (; pNode != NULL; pNode = pNode->m_pNext)
    if (pNode->m_data == searchValue)
        return (CLGNode<T>*) pNode;
return NULL;
}

