//////////////////////////////////////////////////////////////////////////////
/// \file   CLGTextFch.cpp
/// \date   20/05/2003 : date de creation
///
/// \brief
///
/// \date  14/02/2019 : Derniere modification.
///

#include "LibGeneral.h"

//////////////////////////////////////////////////////////////////////
//
CLGTextFch::CLGTextFch( const char * NomFichier /*=NULL*/)
{
SetLongLigneMax( DEFAULT_LONG_LIGNE_MAX ) ;
Clear() ;
if ( NomFichier == NULL )
    m_NomFichier = "NomFichier.txt" ;
else
    m_NomFichier = NomFichier ;
}

//////////////////////////////////////////////////////////////////////
//
CLGTextFch::~CLGTextFch()
{
m_TabLigne.DeleteAll() ;
}

//////////////////////////////////////////////////////////////////////
/// \breif positionne le nom de fichier
void CLGTextFch::SetNom( const char * NomFichier )
{
m_NomFichier = NomFichier ;
}

//////////////////////////////////////////////////////////////////////
//
const char * CLGTextFch::GetNom()
{
return (const char*) m_NomFichier ;
}

//////////////////////////////////////////////////////////////////////
/// \brief Cette fonction permet de definir la taille maximum d'une ligne lors
/// d'un Read().
///
/// \param LongLigneMax [in] : intueur de ligne lors de Read()
///
/// \param m_LongLigneMax [class out] : intueur de ligne lors de Read()
///
void CLGTextFch::SetLongLigneMax( int LongLigneMax )
{
m_LongLigneMax = LongLigneMax ;
}

//////////////////////////////////////////////////////////////////////
/// \brief Cette fonction retourne :
/// 0 : si tout c'est bien passe
short CLGTextFch::Write()
{
// ecriture des lignes du tableau dans le fichier
FILE * FichierSortie = fopen( m_NomFichier , "wb" ) ;
if ( FichierSortie == NULL )
    {
    cout << "Probleme ouverture fichier : " << m_NomFichier << endl ;
    return 1 ;
    }

int ifichier ;
for ( ifichier = 0 ; ifichier < m_TabLigne.GetSize() ; ifichier++ )
    {
    // ecriture chaine de caractere
    fwrite( m_TabLigne[ifichier]->GetBuffer() , sizeof( char ), m_TabLigne[ifichier]->GetLength() , FichierSortie );
    // ecriture fin de ligne
    char c = 0x0a ;
    fwrite( &c , sizeof( char ), 1, FichierSortie );

    if ( ferror( FichierSortie ) )
        {
        fclose( FichierSortie ) ;
        cout << "Probleme ecriture fichier : " << m_NomFichier << endl ;
        return 2 ;
        }
    }
fclose( FichierSortie ) ;
return 0 ;
}

/////////////////////////////////////////////////////////////////////////////
/// \brief Raz des lignes precedentes et growby fonction de la taille du fichier.
void CLGTextFch::Clear()
{
int TailleOctets = 0 ;
m_TabLigne.DeleteAll() ;
m_TabLigne.SetDeleteObjet(true) ;
FILE * FichierEntree = fopen( m_NomFichier , "rb" ) ;
if ( FichierEntree != NULL )
    {
    fseek( FichierEntree , 0 , SEEK_END ) ;
    TailleOctets = ftell(FichierEntree) ;
    fclose(FichierEntree);
    }
int NbLignes = TailleOctets/100 ;
if ( NbLignes < 20 )
    NbLignes = 20 ;
m_TabLigne.SetGrow(NbLignes) ;
}

/////////////////////////////////////////////////////////////////////////////
/// \brief Cette fonction lit le fichier et le met dans m_TabLigne.
///
/// Variables modifiees :
/// \param  m_TabLigne |class ou] :
///
/// \return 2  si erreur lecture fichier
/// \return 1  si erreur ouverture fichier
/// \return 0  si tout c'est bien passe
short CLGTextFch::Read()
{
const int  BufferSize = SIZE_BUFFER_READ ;
char        CharBuffer[BufferSize] ;
int        CountRead ;

// effacement des lignes precedente et positionement GrowBy
Clear() ;

// lecture des lignes dans le fichier et remplissage du tableau
FILE * FichierEntree = fopen( m_NomFichier , "rb" ) ;
if ( FichierEntree == NULL )
    {
    cout << "Probleme ouverture fichier : " << m_NomFichier << "." << endl ;
    return 1 ;
    }

// lecture du fichier
int icharligne = 0 ;
char * TmpLigne = new char [m_LongLigneMax+1] ;
while ( !feof( FichierEntree ) )
    {
    // lecture du fichier
    CountRead = fread ( CharBuffer , sizeof( char ), BufferSize , FichierEntree );

    // test si pas d'erreur
    if( ferror( FichierEntree ) )
        {
        cout << "Probleme lecture fichier : "  << m_NomFichier << "." << endl ;
        fclose( FichierEntree ) ;
        delete [] TmpLigne ;
        return 2 ;
        }

    // parcour du buffer
    int icharbuf ;
    for ( icharbuf = 0 ; icharbuf < CountRead ; icharbuf ++ )
        {
        char Char = CharBuffer[icharbuf] ;

        // elimination des caracteres non desires
        if ( Char == 0x0d )
            continue ;
        // si fin de ligne
        else if ( Char == 0x0a || icharligne >= m_LongLigneMax )
            {
            // caractere de fin de ligne
            TmpLigne[icharligne] = '\0' ;
            icharligne = 0 ;

            // ajout de la ligne au tableau
            CLGString * ps = new CLGString(TmpLigne) ;
            m_TabLigne.Add( ps ) ;
            continue ;
            }

        // ajout du caractere a la ligne
        TmpLigne[icharligne++] = Char ;
        }

    // si fin du fichier
    if ( feof( FichierEntree ) )
        {
        // caractere de fin de ligne
        TmpLigne[icharligne] = '\0' ;

        // ajout de la ligne au tableau
        //CLGString * ps = new CLGString(TmpLigne) ;
        CLGString * ps = new CLGString ;
        *ps = TmpLigne ;
        m_TabLigne.Add( ps ) ;
        break ;
        }
    }

fclose( FichierEntree ) ;
delete [] TmpLigne ;
return 0 ;
}

